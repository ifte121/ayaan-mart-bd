import { db } from "@/db";
import { categories, settings } from "@/db/schema";
import { eq } from "drizzle-orm";
import { cookies } from "next/headers";
import { verifyToken, getUserById } from "@/lib/auth";

export interface LayoutUser {
  id: number;
  name: string;
  role: string;
}

export interface LayoutData {
  categories: (typeof categories.$inferSelect)[];
  settings: Record<string, string>;
  currentUser: LayoutUser | null;
}

/**
 * Fetches the data every page needs to render the shared Header/Footer
 * (active categories, site settings, and the logged-in user, if any).
 *
 * This is wrapped in a try/catch so that a database outage or a missing
 * `DATABASE_URL` (for example right after a fresh deploy, before the
 * environment variable has been configured) degrades gracefully instead of
 * crashing the whole page/build. Pages fall back to sensible empty defaults
 * so the site can still render its static content.
 */
export async function getLayoutData(): Promise<LayoutData> {
  let allCategories: (typeof categories.$inferSelect)[] = [];
  let settingsObj: Record<string, string> = {};

  try {
    const [categoriesResult, settingsResult] = await Promise.all([
      db.select().from(categories).where(eq(categories.is_active, true)),
      db.select().from(settings),
    ]);
    allCategories = categoriesResult;
    settingsResult.forEach((s) => {
      settingsObj[s.key] = s.value || "";
    });
  } catch (error) {
    console.error("[getLayoutData] Failed to load categories/settings from database:", error);
  }

  let currentUser: LayoutUser | null = null;
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get("token")?.value;
    if (token) {
      const decoded = verifyToken(token);
      if (decoded) {
        const user = await getUserById(decoded.userId);
        if (user && !user.is_blocked) {
          currentUser = { id: user.id, name: user.name, role: user.role };
        }
      }
    }
  } catch (error) {
    console.error("[getLayoutData] Failed to resolve current user session:", error);
  }

  return { categories: allCategories, settings: settingsObj, currentUser };
}
