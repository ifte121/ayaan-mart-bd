import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { getLayoutData } from "@/lib/layout-data";

export const dynamic = "force-dynamic";

export default async function TermsPage() {
  const { categories: allCategories, settings: settingsObj, currentUser } = await getLayoutData();

  return (
    <>
      <Header categories={allCategories} settings={settingsObj} currentUser={currentUser} />
      <div className="bg-gray-50 min-h-screen py-12">
        <div className="container-custom max-w-4xl">
          <h1 className="text-3xl font-bold text-gray-800 mb-8">শর্তাবলী</h1>
          <div className="bg-white rounded-2xl shadow-sm border p-8 prose prose-sm max-w-none">
            <p>Ayaan Mart BD এর ওয়েবসাইট ব্যবহার করে আপনি নিম্নলিখিত শর্তাবলীতে সম্মতি প্রকাশ করছেন।</p>
            <h2>অ্যাকাউন্ট</h2><p>আপনি আপনার অ্যাকাউন্টের নিরাপত্তার জন্য দায়ী থাকবেন।</p>
            <h2>পণ্যের মূল্য</h2><p>আমরা যেকোনো সময় পণ্যের মূল্য পরিবর্তনের অধিকার সংরক্ষণ করি।</p>
            <h2>অর্ডার বাতিল</h2><p>কোনো কারণে আমরা অর্ডার বাতিল করার অধিকার সংরক্ষণ করি।</p>
            <h2>পরিবর্তন</h2><p>আমরা যেকোনো সময় এই শর্তাবলী পরিবর্তন করতে পারি।</p>
          </div>
        </div>
      </div>
      <Footer settings={settingsObj} />
    </>
  );
}
