import { db } from "@/db";
import { products, categories } from "@/db/schema";
import { eq, and, desc, ilike, or, sql } from "drizzle-orm";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ProductCard from "@/components/ProductCard";
import Link from "next/link";
import { getLayoutData } from "@/lib/layout-data";

export const dynamic = "force-dynamic";

export default async function ShopPage({ searchParams }: { searchParams: Promise<{ search?: string; category?: string; sort?: string; page?: string; featured?: string; new?: string; min_price?: string; max_price?: string }> }) {
  const params = await searchParams;
  const page = parseInt(params.page || "1");
  const limit = 20;
  const search = params.search;
  const categorySlug = params.category;
  const sort = params.sort || "newest";
  const featured = params.featured === "true";
  const isNew = params.new === "true";
  const minPrice = params.min_price;
  const maxPrice = params.max_price;

  const { categories: allCategories, settings: settingsObj, currentUser } = await getLayoutData();

  let productsResult: (typeof products.$inferSelect)[] = [];
  let total = 0;
  let selectedCategory: typeof categories.$inferSelect | null = null;

  try {
    // Build query
    let whereClause = eq(products.is_active, true);

    if (search) {
      whereClause = and(whereClause, or(ilike(products.name_bn, `%${search}%`), ilike(products.name_en, `%${search}%`)))!;
    }
    if (featured) {
      whereClause = and(whereClause, eq(products.is_featured, true))!;
    }
    if (isNew) {
      whereClause = and(whereClause, eq(products.is_new_arrival, true))!;
    }
    if (minPrice) {
      whereClause = and(whereClause, sql`${products.sale_price} >= ${minPrice}`)!;
    }
    if (maxPrice) {
      whereClause = and(whereClause, sql`${products.sale_price} <= ${maxPrice}`)!;
    }

    // If category slug is provided, find the category and filter
    if (categorySlug) {
      const [cat] = await db.select().from(categories).where(eq(categories.slug, categorySlug)).limit(1);
      if (cat) {
        selectedCategory = cat;
        whereClause = and(whereClause, eq(products.category_id, cat.id))!;
      }
    }

    const orderByClause = sort === "price_low" ? products.sale_price : sort === "price_high" ? desc(products.sale_price) : sort === "discount" ? desc(products.discount_percent) : desc(products.created_at);

    const offset = (page - 1) * limit;
    const [productsQueryResult, countResults] = await Promise.all([
      db.select().from(products).where(whereClause).orderBy(orderByClause).limit(limit).offset(offset),
      db.select({ count: sql<number>`count(*)` }).from(products).where(whereClause),
    ]);

    productsResult = productsQueryResult;
    total = countResults[0]?.count || 0;
  } catch (error) {
    console.error("[ShopPage] Failed to load products from database:", error);
  }

  const totalPages = Math.ceil(total / limit);

  const primaryColor = settingsObj.primary_color || "#dc2626";

  return (
    <>
      <Header categories={allCategories} settings={settingsObj} currentUser={currentUser} />

      <div className="bg-gray-50 min-h-screen">
        <div className="container-custom py-6">
          {/* Breadcrumb */}
          <div className="flex items-center gap-2 text-sm mb-6">
            <Link href="/" className="text-gray-500 hover:text-primary">Home</Link>
            <i className="fas fa-chevron-right text-xs text-gray-400"></i>
            <span className="text-gray-800 font-medium">
              {selectedCategory ? selectedCategory.name_bn : search ? `Search: ${search}` : "সকল পণ্য"}
            </span>
          </div>

          <div className="flex gap-6">
            {/* Sidebar Filters */}
            <div className="w-64 flex-shrink-0 hidden lg:block">
              <div className="bg-white rounded-xl shadow-sm border p-5 sticky top-28">
                <h3 className="font-bold text-gray-800 mb-4">ফিল্টার</h3>

                {/* Categories */}
                <div className="mb-6">
                  <h4 className="text-sm font-semibold text-gray-600 mb-2">ক্যাটাগরি</h4>
                  <div className="space-y-1">
                    <Link href="/shop" className={`block text-sm py-1.5 px-2 rounded transition-colors ${!categorySlug ? "bg-red-50 text-primary font-medium" : "text-gray-600 hover:text-primary"}`}>
                      সকল ক্যাটাগরি
                    </Link>
                    {allCategories.filter((c) => c.parent_id === null).map((cat) => (
                      <Link key={cat.id} href={`/shop?category=${cat.slug}`} className={`block text-sm py-1.5 px-2 rounded transition-colors ${categorySlug === cat.slug ? "bg-red-50 text-primary font-medium" : "text-gray-600 hover:text-primary"}`}>
                        {cat.name_bn}
                      </Link>
                    ))}
                  </div>
                </div>

                {/* Price Range */}
                <div className="mb-6">
                  <h4 className="text-sm font-semibold text-gray-600 mb-2">দামের সীমা</h4>
                  <div className="space-y-1">
                    {[
                      { label: "৳0 - ৳500", min: "0", max: "500" },
                      { label: "৳500 - ৳1,000", min: "500", max: "1000" },
                      { label: "৳1,000 - ৳5,000", min: "1000", max: "5000" },
                      { label: "৳5,000+", min: "5000", max: "" },
                    ].map((range) => (
                      <Link
                        key={range.label}
                        href={`/shop?${categorySlug ? `category=${categorySlug}&` : ""}min_price=${range.min}${range.max ? `&max_price=${range.max}` : ""}`}
                        className="block text-sm py-1.5 px-2 text-gray-600 hover:text-primary rounded"
                      >
                        {range.label}
                      </Link>
                    ))}
                  </div>
                </div>

                <Link href="/shop" className="block text-center text-sm py-2 border rounded-lg text-gray-600 hover:bg-gray-50 mt-4">
                  সব ফিল্টার রিমুভ করুন
                </Link>
              </div>
            </div>

            {/* Products Grid */}
            <div className="flex-1">
              {/* Sort Bar */}
              <div className="bg-white rounded-xl shadow-sm border p-4 mb-4 flex items-center justify-between flex-wrap gap-3">
                <p className="text-sm text-gray-500">
                  {total} টি পণ্য পাওয়া গেছে
                  {search && <span className="font-medium text-gray-700"> "{search}"</span>}
                </p>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-500">সাজান:</span>
                  {[
                    { value: "newest", label: "নতুন" },
                    { value: "price_low", label: "দাম (কম → বেশি)" },
                    { value: "price_high", label: "দাম (বেশি → কম)" },
                    { value: "discount", label: "ডিসকাউন্ট" },
                  ].map((opt) => (
                    <Link
                      key={opt.value}
                      href={`/shop?${search ? `search=${search}&` : ""}${categorySlug ? `category=${categorySlug}&` : ""}sort=${opt.value}`}
                      className={`text-xs px-3 py-1.5 rounded-full transition-colors ${sort === opt.value ? "text-white" : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}
                      style={sort === opt.value ? { backgroundColor: primaryColor } : {}}
                    >
                      {opt.label}
                    </Link>
                  ))}
                </div>
              </div>

              {/* Products */}
              {productsResult.length > 0 ? (
                <>
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                    {productsResult.map((p) => (
                      <ProductCard key={p.id} product={p} />
                    ))}
                  </div>

                  {/* Pagination */}
                  {totalPages > 1 && (
                    <div className="mt-8 flex items-center justify-center gap-2">
                      {page > 1 && (
                        <Link
                          href={`/shop?page=${page - 1}&sort=${sort}${search ? `&search=${search}` : ""}${categorySlug ? `&category=${categorySlug}` : ""}`}
                          className="px-4 py-2 rounded-lg border text-sm hover:bg-gray-50"
                        >
                          <i className="fas fa-chevron-left"></i>
                        </Link>
                      )}
                      {Array.from({ length: Math.min(totalPages, 5) }, (_, i) => i + 1).map((p) => (
                        <Link
                          key={p}
                          href={`/shop?page=${p}&sort=${sort}${search ? `&search=${search}` : ""}${categorySlug ? `&category=${categorySlug}` : ""}`}
                          className={`px-4 py-2 rounded-lg text-sm font-medium ${p === page ? "text-white" : "border hover:bg-gray-50"}`}
                          style={p === page ? { backgroundColor: primaryColor } : {}}
                        >
                          {p}
                        </Link>
                      ))}
                      {page < totalPages && (
                        <Link
                          href={`/shop?page=${page + 1}&sort=${sort}${search ? `&search=${search}` : ""}${categorySlug ? `&category=${categorySlug}` : ""}`}
                          className="px-4 py-2 rounded-lg border text-sm hover:bg-gray-50"
                        >
                          <i className="fas fa-chevron-right"></i>
                        </Link>
                      )}
                    </div>
                  )}
                </>
              ) : (
                <div className="bg-white rounded-xl border p-12 text-center">
                  <div className="text-6xl mb-4">🔍</div>
                  <h3 className="text-xl font-bold text-gray-800 mb-2">কোনো পণ্য পাওয়া যায়নি</h3>
                  <p className="text-gray-500 mb-6">আপনার সার্চের সাথে মিলে এমন কোনো পণ্য পাওয়া যায়নি।</p>
                  <Link href="/shop" className="btn-primary">সকল পণ্য দেখুন</Link>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <Footer settings={settingsObj} />
    </>
  );
}
