"use client";
import { useState, useEffect, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import HeaderClient from "@/components/HeaderClient";
import FooterClient from "@/components/FooterClient";

export default function AccountPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-gray-50 flex items-center justify-center"><div className="spinner"></div></div>}>
      <AccountContent />
    </Suspense>
  );
}

function AccountContent() {
  const [user, setUser] = useState<any>(null);
  const [orders, setOrders] = useState<any[]>([]);
  const [tab, setTab] = useState("profile");
  const [loading, setLoading] = useState(true);
  const router = useRouter();
  const searchParams = useSearchParams();

  useEffect(() => {
    const t = searchParams.get("tab");
    if (t) setTab(t);
  }, [searchParams]);

  useEffect(() => {
    fetch("/api/auth/me").then((r) => r.json()).then(async (d) => {
      if (!d.user) {
        router.push("/login");
        return;
      }
      setUser(d.user);
      // Fetch orders
      const res = await fetch("/api/orders");
      const od = await res.json();
      setOrders(od.orders || []);
      setLoading(false);
    });
  }, [router]);

  if (loading) {
    return (
      <>
        <HeaderClient />
        <div className="min-h-screen bg-gray-50 flex items-center justify-center">
          <div className="spinner"></div>
        </div>
        <FooterClient />
      </>
    );
  }

  if (!user) return null;

  const handleLogout = () => {
    document.cookie = "token=; path=/; max-age=0";
    router.push("/");
    router.refresh();
  };

  return (
    <>
      <HeaderClient />
      <div className="bg-gray-50 min-h-screen py-6">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {/* Sidebar */}
            <div className="md:col-span-1">
              <div className="bg-white rounded-xl shadow-sm border p-5 sticky top-28">
                <div className="text-center mb-4">
                  <div className="w-16 h-16 bg-primary/10 rounded-full mx-auto flex items-center justify-center text-2xl text-primary">
                    <i className="fas fa-user"></i>
                  </div>
                  <h3 className="font-bold mt-2">{user.name}</h3>
                  <p className="text-xs text-gray-400">{user.email}</p>
                </div>
                <nav className="space-y-1">
                  {[
                    { id: "profile", label: "My Profile", icon: "fa-user" },
                    { id: "orders", label: "My Orders", icon: "fa-box" },
                    { id: "wishlist", label: "Wishlist", icon: "fa-heart" },
                  ].map((nav) => (
                    <button
                      key={nav.id}
                      onClick={() => setTab(nav.id)}
                      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors ${tab === nav.id ? "bg-primary text-white" : "text-gray-600 hover:bg-gray-50"}`}
                    >
                      <i className={`fas ${nav.icon} w-5`}></i>{nav.label}
                    </button>
                  ))}
                  <button onClick={handleLogout} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-red-500 hover:bg-red-50 transition-colors">
                    <i className="fas fa-sign-out-alt w-5"></i>Logout
                  </button>
                </nav>
              </div>
            </div>

            {/* Main Content */}
            <div className="md:col-span-3">
              {tab === "profile" && (
                <div className="bg-white rounded-xl shadow-sm border p-6">
                  <h2 className="text-xl font-bold mb-6">My Profile</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="form-label">নাম</label>
                      <input type="text" value={user.name} className="form-input bg-gray-50" readOnly />
                    </div>
                    <div>
                      <label className="form-label">ইমেইল</label>
                      <input type="email" value={user.email} className="form-input bg-gray-50" readOnly />
                    </div>
                    <div>
                      <label className="form-label">ফোন</label>
                      <input type="tel" value={user.phone || "-"} className="form-input bg-gray-50" readOnly />
                    </div>
                    <div>
                      <label className="form-label">রোল</label>
                      <input type="text" value={user.role} className="form-input bg-gray-50" readOnly />
                    </div>
                    <div className="md:col-span-2">
                      <label className="form-label">ঠিকানা</label>
                      <input type="text" value={user.address || "-"} className="form-input bg-gray-50" readOnly />
                    </div>
                  </div>
                </div>
              )}

              {tab === "orders" && (
                <div className="bg-white rounded-xl shadow-sm border p-6">
                  <h2 className="text-xl font-bold mb-6">My Orders</h2>
                  {orders.length === 0 ? (
                    <div className="text-center py-12 text-gray-500">
                      <div className="text-5xl mb-3">📦</div>
                      <p>আপনার কোনো অর্ডার নেই</p>
                      <Link href="/shop" className="text-primary font-medium mt-2 inline-block">শপিং শুরু করুন</Link>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {orders.map((order) => (
                        <div key={order.id} className="border rounded-xl p-4 hover:shadow-sm transition-shadow">
                          <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
                            <div>
                              <span className="font-bold text-sm">#{order.order_number}</span>
                              <span className="text-xs text-gray-400 ml-2">{new Date(order.created_at).toLocaleDateString("bn-BD")}</span>
                            </div>
                            <span className={`text-xs px-3 py-1 rounded-full font-medium ${
                              order.order_status === "delivered" ? "bg-green-100 text-green-700" :
                              order.order_status === "cancelled" ? "bg-red-100 text-red-700" :
                              order.order_status === "shipped" ? "bg-blue-100 text-blue-700" :
                              order.order_status === "processing" ? "bg-yellow-100 text-yellow-700" :
                              "bg-gray-100 text-gray-700"
                            }`}>
                              {order.order_status.toUpperCase()}
                            </span>
                          </div>
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-gray-500">মোট: <span className="font-bold text-gray-800">৳{parseInt(order.total).toLocaleString("en-BD")}</span></span>
                            <span className="text-gray-500">পেমেন্ট: {order.payment_method.toUpperCase()}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {tab === "wishlist" && (
                <div className="bg-white rounded-xl shadow-sm border p-6">
                  <h2 className="text-xl font-bold mb-6">Wishlist</h2>
                  <div className="text-center py-12 text-gray-500">
                    <div className="text-5xl mb-3">❤️</div>
                    <p>Wishlist feature coming soon</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      <FooterClient />
    </>
  );
}
