import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { products, categories, reviews } from "@/db/schema";
import { eq, desc, and, ilike, or, gte, lte } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const slug = searchParams.get("slug");

    if (slug) {
      // Get single product
      const [product] = await db
        .select()
        .from(products)
        .where(and(eq(products.slug, slug), eq(products.is_active, true)))
        .limit(1);

      if (!product) {
        return NextResponse.json({ error: "Product not found" }, { status: 404 });
      }

      // Get reviews
      const productReviews = await db
        .select()
        .from(reviews)
        .where(and(eq(reviews.product_id, product.id), eq(reviews.is_approved, true)))
        .orderBy(desc(reviews.created_at));

      // Get related products
      const relatedProducts = await db
        .select()
        .from(products)
        .where(and(eq(products.category_id, product.category_id), eq(products.is_active, true)))
        .limit(5);

      return NextResponse.json({ product, reviews: productReviews, related: relatedProducts });
    }

    // Get all products
    const page = parseInt(searchParams.get("page") || "1");
    const limit = parseInt(searchParams.get("limit") || "20");
    const search = searchParams.get("search");
    const categoryId = searchParams.get("category");
    const minPrice = searchParams.get("min_price");
    const maxPrice = searchParams.get("max_price");
    const sort = searchParams.get("sort") || "newest";
    const featured = searchParams.get("featured") === "true";
    const newArrival = searchParams.get("new") === "true";

    let whereClause = eq(products.is_active, true);

    if (search) {
      whereClause = and(
        whereClause,
        or(ilike(products.name_bn, `%${search}%`), ilike(products.name_en, `%${search}%`), ilike(products.brand || "", `%${search}%`))
      )!;
    }
    if (categoryId) {
      whereClause = and(whereClause, eq(products.category_id, parseInt(categoryId)))!;
    }
    if (minPrice) {
      whereClause = and(whereClause, gte(products.sale_price, minPrice))!;
    }
    if (maxPrice) {
      whereClause = and(whereClause, lte(products.sale_price, maxPrice))!;
    }
    if (featured) {
      whereClause = and(whereClause, eq(products.is_featured, true))!;
    }
    if (newArrival) {
      whereClause = and(whereClause, eq(products.is_new_arrival, true))!;
    }

    const orderByClause = sort === "price_low" ? products.sale_price : sort === "price_high" ? desc(products.sale_price) : sort === "discount" ? desc(products.discount_percent) : desc(products.created_at);

    const offset = (page - 1) * limit;

    const [productsResult, countResult] = await Promise.all([
      db.select().from(products).where(whereClause).orderBy(orderByClause).limit(limit).offset(offset),
      db.select({ count: products.id }).from(products).where(whereClause),
    ]);

    return NextResponse.json({
      products: productsResult,
      total: countResult.length,
      page,
      totalPages: Math.ceil(countResult.length / limit),
    });
  } catch (error) {
    console.error("Products API error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
