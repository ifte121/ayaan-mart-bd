import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { reviews, users } from "@/db/schema";
import { eq, and, desc } from "drizzle-orm";
import { verifyToken } from "@/lib/auth";
import { cookies } from "next/headers";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const productId = searchParams.get("product_id");

  if (!productId) {
    return NextResponse.json({ reviews: [] });
  }

  const reviewList = await db
    .select()
    .from(reviews)
    .where(and(eq(reviews.product_id, parseInt(productId)), eq(reviews.is_approved, true)))
    .orderBy(desc(reviews.created_at));

  return NextResponse.json({ reviews: reviewList });
}

export async function POST(req: NextRequest) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get("token")?.value;
    if (!token) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const decoded = verifyToken(token);
    if (!decoded) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json();
    const { productId, rating, comment } = body;

    if (!productId || !rating) {
      return NextResponse.json({ error: "Product ID and rating are required" }, { status: 400 });
    }

    await db.insert(reviews).values({
      product_id: parseInt(productId),
      user_id: decoded.userId,
      rating: parseInt(rating),
      comment: comment || null,
      is_approved: false,
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Review POST error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
