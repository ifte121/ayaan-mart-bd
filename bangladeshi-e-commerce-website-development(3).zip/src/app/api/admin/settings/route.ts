import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { settings } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    const allSettings = await db.select().from(settings);
    const settingsObj: Record<string, string> = {};
    allSettings.forEach((s) => { settingsObj[s.key] = s.value || ""; });
    return NextResponse.json({ settings: settingsObj });
  } catch (error) {
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const { settings: newSettings } = body;
    if (!newSettings || typeof newSettings !== "object") {
      return NextResponse.json({ error: "Invalid settings data" }, { status: 400 });
    }
    for (const [key, value] of Object.entries(newSettings)) {
      const existing = await db.select().from(settings).where(eq(settings.key, key)).limit(1);
      if (existing.length > 0) {
        await db.update(settings).set({ value: String(value) }).where(eq(settings.key, key));
      } else {
        await db.insert(settings).values({ key, value: String(value) });
      }
    }
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
