import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders, users, products } from "@/db/schema";
import { eq, and, gte, lte, sql } from "drizzle-orm";

export async function GET() {
  try {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

    // Total stats
    const [totalOrders] = await db.select({ count: sql<number>`count(*)` }).from(orders);
    const [totalRevenue] = await db.select({ sum: sql<number>`coalesce(sum(${orders.total}), 0)` }).from(orders).where(eq(orders.order_status, "delivered"));
    const [totalCustomers] = await db.select({ count: sql<number>`count(*)` }).from(users).where(eq(users.role, "customer"));
    const [totalProducts] = await db.select({ count: sql<number>`count(*)` }).from(products).where(eq(products.is_active, true));

    // Today's orders
    const [todayOrders] = await db.select({ count: sql<number>`count(*)` }).from(orders).where(gte(orders.created_at, today));
    const [todayRevenue] = await db.select({ sum: sql<number>`coalesce(sum(${orders.total}), 0)` }).from(orders).where(gte(orders.created_at, today));

    // Week orders
    const [weekOrders] = await db.select({ count: sql<number>`count(*)` }).from(orders).where(gte(orders.created_at, weekAgo));
    const [weekRevenue] = await db.select({ sum: sql<number>`coalesce(sum(${orders.total}), 0)` }).from(orders).where(gte(orders.created_at, weekAgo));

    // Month orders
    const [monthOrders] = await db.select({ count: sql<number>`count(*)` }).from(orders).where(gte(orders.created_at, monthStart));
    const [monthRevenue] = await db.select({ sum: sql<number>`coalesce(sum(${orders.total}), 0)` }).from(orders).where(gte(orders.created_at, monthStart));

    // Pending orders
    const [pendingOrders] = await db.select({ count: sql<number>`count(*)` }).from(orders).where(eq(orders.order_status, "pending"));

    // Low stock products
    const lowStock = await db.select().from(products).where(and(eq(products.is_active, true), sql`${products.stock_quantity} <= 5`)).limit(10);

    // Recent orders
    const recentOrders = await db.select().from(orders).orderBy(sql`${orders.created_at} DESC`).limit(10);

    return NextResponse.json({
      stats: {
        totalOrders: totalOrders.count,
        totalRevenue: parseFloat(totalRevenue.sum as unknown as string),
        totalCustomers: totalCustomers.count,
        totalProducts: totalProducts.count,
        todayOrders: todayOrders.count,
        todayRevenue: parseFloat(todayRevenue.sum as unknown as string),
        weekOrders: weekOrders.count,
        weekRevenue: parseFloat(weekRevenue.sum as unknown as string),
        monthOrders: monthOrders.count,
        monthRevenue: parseFloat(monthRevenue.sum as unknown as string),
        pendingOrders: pendingOrders.count,
      },
      lowStock,
      recentOrders,
    });
  } catch (error) {
    console.error("Admin stats error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
