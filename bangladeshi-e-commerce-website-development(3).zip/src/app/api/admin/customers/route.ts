import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq, and, desc, sql } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (id) {
      const [user] = await db.select().from(users).where(eq(users.id, parseInt(id))).limit(1);
      return NextResponse.json({ user });
    }

    const customers = await db.select().from(users).where(eq(users.role, "customer")).orderBy(desc(users.created_at));
    return NextResponse.json({ customers });
  } catch (error) {
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, is_blocked } = body;
    if (!id) return NextResponse.json({ error: "User ID is required" }, { status: 400 });
    await db.update(users).set({ is_blocked: is_blocked === true }).where(eq(users.id, id));
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
