import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { orders, orderItems } from "@/db/schema";
import { eq, and, desc, sql } from "drizzle-orm";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const page = parseInt(searchParams.get("page") || "1");
  const limit = parseInt(searchParams.get("limit") || "20");
  const status = searchParams.get("status");
  const orderId = searchParams.get("id");

  if (orderId) {
    const [order] = await db.select().from(orders).where(eq(orders.id, parseInt(orderId))).limit(1);
    if (!order) return NextResponse.json({ error: "Order not found" }, { status: 404 });
    const items = await db.select().from(orderItems).where(eq(orderItems.order_id, order.id));
    return NextResponse.json({ order: { ...order, items } });
  }

  let whereClause = sql`1=1`;
  if (status) {
    whereClause = eq(orders.order_status, status);
  }

  const allOrders = await db.select().from(orders).where(whereClause).orderBy(desc(orders.created_at)).limit(limit).offset((page - 1) * limit);

  const [{ count }] = await db.select({ count: sql<number>`count(*)` }).from(orders).where(whereClause);

  return NextResponse.json({ orders: allOrders, total: count, totalPages: Math.ceil(count / limit) });
}

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, status } = body;

    if (!id || !status) {
      return NextResponse.json({ error: "Order ID and status are required" }, { status: 400 });
    }

    await db.update(orders).set({ order_status: status, updated_at: new Date() }).where(eq(orders.id, id));

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Order update error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
