import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { banners } from "@/db/schema";
import { eq, asc, desc } from "drizzle-orm";

export async function GET() {
  const allBanners = await db.select().from(banners).orderBy(asc(banners.sort_order));
  return NextResponse.json({ banners: allBanners });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { title, image, link, sort_order } = body;
    if (!title || !image) return NextResponse.json({ error: "Title and image required" }, { status: 400 });
    const [banner] = await db.insert(banners).values({ title, image, link: link || null, sort_order: sort_order || 0 }).returning();
    return NextResponse.json({ success: true, banner });
  } catch (error) {
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, is_active } = body;
    if (!id) return NextResponse.json({ error: "ID required" }, { status: 400 });
    await db.update(banners).set({ is_active: is_active !== false }).where(eq(banners.id, id));
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { id } = await req.json();
    if (!id) return NextResponse.json({ error: "ID required" }, { status: 400 });
    await db.delete(banners).where(eq(banners.id, id));
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
