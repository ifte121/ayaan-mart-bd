import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { coupons } from "@/db/schema";
import { eq, and, desc } from "drizzle-orm";

export async function GET() {
  try {
    const allCoupons = await db.select().from(coupons).orderBy(desc(coupons.created_at));
    return NextResponse.json({ coupons: allCoupons });
  } catch (error) {
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { code, description, discount_type, discount_value, min_order_amount, max_usage, expiry_date } = body;
    if (!code || !discount_value) return NextResponse.json({ error: "Code and discount value required" }, { status: 400 });
    const [coupon] = await db
      .insert(coupons)
      .values({
        code: code.toUpperCase(),
        description: description || null,
        discount_type: discount_type || "percentage",
        discount_value: String(discount_value),
        min_order_amount: String(min_order_amount || 0),
        max_usage: max_usage || 0,
        expiry_date: expiry_date ? new Date(expiry_date) : null,
      })
      .returning();
    return NextResponse.json({ success: true, coupon });
  } catch (error) {
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, is_active } = body;
    if (!id) return NextResponse.json({ error: "ID required" }, { status: 400 });
    await db.update(coupons).set({ is_active: is_active !== false }).where(eq(coupons.id, id));
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { id } = await req.json();
    if (!id) return NextResponse.json({ error: "ID required" }, { status: 400 });
    await db.delete(coupons).where(eq(coupons.id, id));
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
