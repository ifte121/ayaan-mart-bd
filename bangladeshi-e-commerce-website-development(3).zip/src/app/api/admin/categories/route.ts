import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { categories } from "@/db/schema";
import { eq, and, asc, sql } from "drizzle-orm";

export async function GET() {
  try {
    const allCats = await db.select().from(categories).orderBy(asc(categories.sort_order));
    return NextResponse.json({ categories: allCats });
  } catch (error) {
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, is_active } = body;
    if (!id) return NextResponse.json({ error: "Category ID required" }, { status: 400 });
    await db.update(categories).set({ is_active: is_active !== false }).where(eq(categories.id, id));
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { name_bn, name_en, icon, parent_id, sort_order } = body;
    if (!name_bn || !name_en) return NextResponse.json({ error: "Name required" }, { status: 400 });

    const slug = `${name_en.toLowerCase().replace(/[^a-z0-9]+/g, "-")}-${Date.now()}`;
    const [cat] = await db
      .insert(categories)
      .values({ name_bn, name_en, slug, icon: icon || null, parent_id: parent_id || null, sort_order: sort_order || 0 })
      .returning();

    return NextResponse.json({ success: true, category: cat });
  } catch (error) {
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { id } = await req.json();
    if (!id) return NextResponse.json({ error: "ID required" }, { status: 400 });
    await db.delete(categories).where(eq(categories.id, id));
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
