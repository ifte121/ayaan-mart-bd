import { NextRequest, NextResponse } from "next/server";
import { loginUser } from "@/lib/auth";
import { sendLoginAlertEmail } from "@/lib/email";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { email, password } = body;

    if (!email || !password) {
      return NextResponse.json({ error: "Email and password are required" }, { status: 400 });
    }

    const result = await loginUser(email, password);

    if (result.error) {
      return NextResponse.json({ error: result.error }, { status: 401 });
    }

    // 🔔 Send login alert email to customer
    if (result.user) {
      // fire-and-forget (don't block login response)
      sendLoginAlertEmail(result.user.id, result.user.email, result.user.name).catch((err) =>
        console.error("Login alert email failed:", err)
      );
    }

    const response = NextResponse.json({ success: true, user: result.user });
    response.cookies.set("token", result.token!, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 7 * 24 * 60 * 60,
      path: "/",
    });

    return response;
  } catch (error) {
    console.error("Login error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
