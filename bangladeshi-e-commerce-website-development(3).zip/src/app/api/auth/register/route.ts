import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { hashPassword, generateToken } from "@/lib/auth";
import { generateOTP, sendOTPEmail, sendOTPMobile } from "@/lib/email";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { name, email, password, phone, action, otp } = body;

    // ---------- STEP 1: Register ----------
    if (action === "register" || !action) {
      if (!name || !email || !password || !phone) {
        return NextResponse.json({ error: "Name, email, phone, and password are required" }, { status: 400 });
      }

      // Check existing user
      const [existingUser] = await db.select().from(users).where(eq(users.email, email)).limit(1);
      if (existingUser) {
        return NextResponse.json({ error: "Email already registered" }, { status: 400 });
      }

      const hashedPassword = await hashPassword(password);
      // Same OTP is sent to both mobile and email — verification is done via mobile OTP only
      const sharedOTP = generateOTP();
      const otpExpiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

      const [newUser] = await db
        .insert(users)
        .values({
          name,
          email,
          password: hashedPassword,
          phone,
          role: "customer",
          is_verified: false,
          email_otp: sharedOTP,
          mobile_otp: sharedOTP,
          otp_expires_at: otpExpiresAt,
        })
        .returning({
          id: users.id,
          name: users.name,
          email: users.email,
          phone: users.phone,
        });

      // Send the SAME OTP to both mobile (primary verification channel) and email (for reference)
      await Promise.all([
        sendOTPMobile(phone, sharedOTP),
        sendOTPEmail(email, name, sharedOTP),
      ]);

      return NextResponse.json({
        success: true,
        message: "Registration initiated. Please verify using the OTP sent to your mobile number.",
        userId: newUser.id,
        email: newUser.email,
        phone: newUser.phone,
      });
    }

    // ---------- STEP 2: Verify OTP (Mobile number only) ----------
    if (action === "verify_otp") {
      const { email: verifyEmail } = body;

      if (!verifyEmail || !otp) {
        return NextResponse.json({ error: "Email and OTP are required" }, { status: 400 });
      }

      const [user] = await db.select().from(users).where(eq(users.email, verifyEmail)).limit(1);
      if (!user) {
        return NextResponse.json({ error: "User not found" }, { status: 404 });
      }

      if (user.is_verified) {
        return NextResponse.json({ error: "Account already verified" }, { status: 400 });
      }

      if (!user.otp_expires_at || user.otp_expires_at < new Date()) {
        return NextResponse.json({ error: "OTP has expired. Please register again." }, { status: 400 });
      }

      // Verification is strictly against the Mobile OTP (same value was also sent to email)
      const isValidOTP = user.mobile_otp === otp;

      if (!isValidOTP) {
        return NextResponse.json({ error: "Invalid OTP. Please check the code sent to your mobile number." }, { status: 400 });
      }

      // Mark verified
      await db
        .update(users)
        .set({
          is_verified: true,
          email_otp: null,
          mobile_otp: null,
          otp_expires_at: null,
        })
        .where(eq(users.email, verifyEmail));

      const token = generateToken(user.id, user.role);

      const response = NextResponse.json({
        success: true,
        message: "Mobile number verified successfully! Your account is now active.",
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          phone: user.phone,
          role: user.role,
        },
      });

      response.cookies.set("token", token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax",
        maxAge: 7 * 24 * 60 * 60,
        path: "/",
      });

      return response;
    }

    // ---------- Resend OTP ----------
    if (action === "resend_otp") {
      const { email: resendEmail } = body;
      if (!resendEmail) {
        return NextResponse.json({ error: "Email is required" }, { status: 400 });
      }

      const [user] = await db.select().from(users).where(eq(users.email, resendEmail)).limit(1);
      if (!user) {
        return NextResponse.json({ error: "User not found" }, { status: 404 });
      }
      if (user.is_verified) {
        return NextResponse.json({ error: "Account already verified" }, { status: 400 });
      }

      const sharedOTP = generateOTP();
      const otpExpiresAt = new Date(Date.now() + 10 * 60 * 1000);

      await db
        .update(users)
        .set({ email_otp: sharedOTP, mobile_otp: sharedOTP, otp_expires_at: otpExpiresAt })
        .where(eq(users.email, resendEmail));

      await Promise.all([
        sendOTPMobile(user.phone || "", sharedOTP),
        sendOTPEmail(user.email, user.name, sharedOTP),
      ]);

      return NextResponse.json({ success: true, message: "OTP resent to your mobile number." });
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 });
  } catch (error) {
    console.error("Register error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
