import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { coupons } from "@/db/schema";
import { eq, and, gte, lte } from "drizzle-orm";

export async function POST(req: NextRequest) {
  try {
    const { code, orderTotal } = await req.json();

    if (!code) {
      return NextResponse.json({ error: "Coupon code is required" }, { status: 400 });
    }

    const coupon = await db
      .select()
      .from(coupons)
      .where(and(eq(coupons.code, code.toUpperCase()), eq(coupons.is_active, true)))
      .limit(1);

    if (coupon.length === 0) {
      return NextResponse.json({ error: "Invalid coupon code" }, { status: 400 });
    }

    const c = coupon[0];

    if (c.max_usage > 0 && c.used_count >= c.max_usage) {
      return NextResponse.json({ error: "Coupon usage limit reached" }, { status: 400 });
    }

    if (c.expiry_date && c.expiry_date < new Date()) {
      return NextResponse.json({ error: "Coupon has expired" }, { status: 400 });
    }

    const minAmount = parseFloat(c.min_order_amount);
    if (minAmount > 0 && (orderTotal || 0) < minAmount) {
      return NextResponse.json({ error: `Minimum order amount is ৳${minAmount}` }, { status: 400 });
    }

    let discount = 0;
    if (c.discount_type === "percentage") {
      discount = (orderTotal * parseFloat(c.discount_value)) / 100;
    } else {
      discount = parseFloat(c.discount_value);
    }

    return NextResponse.json({ success: true, discount, code: c.code });
  } catch (error) {
    console.error("Coupon error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
