import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { orders, orderItems, products, cart } from "@/db/schema";
import { eq, and, desc } from "drizzle-orm";
import { verifyToken } from "@/lib/auth";
import { cookies } from "next/headers";
import { generateOrderNumber } from "@/lib/auth";

export async function GET(req: NextRequest) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get("token")?.value;
    if (!token) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const decoded = verifyToken(token);
    if (!decoded) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { searchParams } = new URL(req.url);
    const page = parseInt(searchParams.get("page") || "1");
    const limit = parseInt(searchParams.get("limit") || "10");
    const status = searchParams.get("status");

    let whereClause = eq(orders.user_id, decoded.userId);
    if (status) {
      whereClause = and(eq(orders.user_id, decoded.userId), eq(orders.order_status, status))!;
    }

    const userOrders = await db.select().from(orders).where(whereClause).orderBy(desc(orders.created_at)).limit(limit).offset((page - 1) * limit);

    // Get items for each order
    for (const order of userOrders) {
      const items = await db.select().from(orderItems).where(eq(orderItems.order_id, order.id));
      (order as any).items = items;
    }

    return NextResponse.json({ orders: userOrders });
  } catch (error) {
    console.error("Orders GET error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get("token")?.value;
    if (!token) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const decoded = verifyToken(token);
    if (!decoded) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json();
    const { cartItems, shippingAddress, city, area, deliveryType, deliveryCharge, paymentMethod, transactionId, notes, couponCode, couponDiscount } = body;

    if (!cartItems || cartItems.length === 0) {
      return NextResponse.json({ error: "Cart is empty" }, { status: 400 });
    }

    const orderNumber = generateOrderNumber();
    const subtotal = cartItems.reduce((sum: number, item: any) => sum + item.price * item.quantity, 0);
    const total = subtotal + (parseFloat(deliveryCharge) || 0) - (parseFloat(couponDiscount) || 0);

    const [order] = await db
      .insert(orders)
      .values({
        order_number: orderNumber,
        user_id: decoded.userId,
        customer_name: body.customerName,
        customer_email: body.customerEmail,
        customer_phone: body.customerPhone,
        shipping_address: shippingAddress,
        city,
        area: area || null,
        delivery_type: deliveryType,
        delivery_charge: String(deliveryCharge || 0),
        subtotal: String(subtotal),
        coupon_code: couponCode || null,
        coupon_discount: String(couponDiscount || 0),
        total: String(total),
        payment_method: paymentMethod,
        payment_status: paymentMethod === "cod" ? "pending" : "pending",
        transaction_id: transactionId || null,
        order_status: "pending",
        notes: notes || null,
      })
      .returning();

    // Insert order items
    for (const item of cartItems) {
      await db.insert(orderItems).values({
        order_id: order.id,
        product_id: item.id,
        product_name: item.name_en,
        product_image: item.image,
        quantity: item.quantity,
        price: String(item.price),
        total: String(item.price * item.quantity),
      });

      // Update stock
      await db
        .update(products)
        .set({ stock_quantity: Math.max(0, item.stock - item.quantity) })
        .where(eq(products.id, item.id));
    }

    // Clear cart
    await db.delete(cart).where(eq(cart.user_id, decoded.userId));

    return NextResponse.json({ success: true, order });
  } catch (error) {
    console.error("Order POST error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
