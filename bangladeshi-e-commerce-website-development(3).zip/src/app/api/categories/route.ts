import { NextResponse } from "next/server";
import { db } from "@/db";
import { categories } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    const cats = await db.select().from(categories).where(eq(categories.is_active, true)).orderBy(categories.sort_order);
    return NextResponse.json({ categories: cats });
  } catch (error) {
    console.error("Categories API error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
