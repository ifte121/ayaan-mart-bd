import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { getLayoutData } from "@/lib/layout-data";

export const dynamic = "force-dynamic";

export default async function FAQPage() {
  const { categories: allCategories, settings: settingsObj, currentUser } = await getLayoutData();

  const faqs = [
    { q: "অর্ডার কিভাবে করবো?", a: "আপনার পছন্দের পণ্যটি কার্টে যোগ করে Checkout পেজে গিয়ে শিপিং তথ্য ও পেমেন্ট মাধ্যম সিলেক্ট করে অর্ডার কনফার্ম করুন।" },
    { q: "ডেলিভারি চার্জ কত?", a: `ঢাকার ভিতরে ডেলিভারি চার্জ ৳${settingsObj.delivery_inside_dhaka || "60"} এবং ঢাকার বাইরে ৳${settingsObj.delivery_outside_dhaka || "120"}।` },
    { q: "কত দিনে ডেলিভারি পাবো?", a: "ঢাকার ভিতরে ২৪-৪৮ ঘণ্টার মধ্যে এবং ঢাকার বাইরে ২-৫ দিনের মধ্যে ডেলিভারি পেয়ে যাবেন।" },
    { q: "পেমেন্ট কিভাবে করবো?", a: "আপনি ক্যাশ অন ডেলিভারি (COD), bKash, Nagad অথবা Rocket এর মাধ্যমে পেমেন্ট করতে পারবেন।" },
    { q: "পণ্য রিটার্ন কিভাবে করবো?", a: "পণ্য পাওয়ার ৭ দিনের মধ্যে আমাদের কাস্টমার সার্ভিসে যোগাযোগ করে রিটার্ন রিকোয়েস্ট করতে পারবেন।" },
    { q: "পণ্য নষ্ট/ড্যামেজ হলে কি করবো?", a: "ডেলিভারির সময় পণ্য চেক করে নিন। কোনো ড্যামেজ থাকলে সাথে সাথে ডেলিভারি ম্যানকে জানিয়ে আমাদের কাস্টমার সার্ভিসে কল দিন।" },
  ];

  return (
    <>
      <Header categories={allCategories} settings={settingsObj} currentUser={currentUser} />
      <div className="bg-gray-50 min-h-screen py-12">
        <div className="container-custom max-w-3xl">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">সাধারণ জিজ্ঞাসা (FAQ)</h1>
          <p className="text-gray-500 mb-8">আপনার জিজ্ঞাসিত প্রশ্নের উত্তর এখানে পাবেন</p>
          <div className="space-y-3">
            {faqs.map((faq, i) => (
              <details key={i} className="bg-white rounded-xl shadow-sm border overflow-hidden group">
                <summary className="px-6 py-4 cursor-pointer font-semibold text-gray-800 flex items-center justify-between hover:text-primary transition-colors">
                  <span>{faq.q}</span>
                  <i className="fas fa-chevron-down text-xs group-open:rotate-180 transition-transform"></i>
                </summary>
                <div className="px-6 pb-4 text-gray-600">{faq.a}</div>
              </details>
            ))}
          </div>
        </div>
      </div>
      <Footer settings={settingsObj} />
    </>
  );
}
