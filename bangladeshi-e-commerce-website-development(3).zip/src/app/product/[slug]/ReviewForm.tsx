"use client";
import { useState } from "react";

export default function ReviewForm({ productId }: { productId: number }) {
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productId, rating, comment }),
      });
      const data = await res.json();
      if (data.success) {
        setSubmitted(true);
        setComment("");
      }
    } catch (err) {
      console.error(err);
    }
    setLoading(false);
  };

  if (submitted) {
    return (
      <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-center">
        <i className="fas fa-check-circle text-green-500 text-2xl mb-2"></i>
        <p className="text-green-700 text-sm">আপনার রিভিউ সাবমিট হয়েছে! অ্যাপ্রুভালের পর দেখানো হবে।</p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      <div>
        <label className="text-sm font-medium text-gray-700 mb-1 block">আপনার রেটিং</label>
        <div className="flex gap-1 text-xl">
          {[1, 2, 3, 4, 5].map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => setRating(s)}
              className={s <= rating ? "text-yellow-400" : "text-gray-300"}
            >
              <i className="fas fa-star"></i>
            </button>
          ))}
        </div>
      </div>
      <div>
        <label className="text-sm font-medium text-gray-700 mb-1 block">আপনার মন্তব্য</label>
        <textarea
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          rows={3}
          className="form-input"
          placeholder="আপনার অভিজ্ঞতা শেয়ার করুন..."
        ></textarea>
      </div>
      <button
        type="submit"
        disabled={loading}
        className="btn-primary text-sm"
      >
        {loading ? <><i className="fas fa-spinner fa-spin mr-1"></i> সাবমিট হচ্ছে...</> : "রিভিউ সাবমিট করুন"}
      </button>
    </form>
  );
}
