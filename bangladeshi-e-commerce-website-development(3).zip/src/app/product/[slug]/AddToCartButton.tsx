"use client";
import { useState } from "react";
import { useCartStore } from "@/lib/store";

interface AddToCartButtonProps {
  product: {
    id: number;
    name_bn: string;
    name_en: string;
    sale_price: string;
    main_image: string | null;
    stock_quantity: number;
  };
  primaryColor: string;
}

export default function AddToCartButton({ product, primaryColor }: AddToCartButtonProps) {
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);
  const { addItem } = useCartStore();

  const handleAdd = () => {
    addItem({
      id: product.id,
      name_bn: product.name_bn,
      name_en: product.name_en,
      price: parseFloat(product.sale_price),
      image: product.main_image || "https://placehold.co/500x500/e2e8f0/333?text=No+Image",
      quantity,
      stock: product.stock_quantity,
    });
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <div className="flex items-center border rounded-lg">
          <button
            onClick={() => setQuantity(Math.max(1, quantity - 1))}
            className="px-3 py-2 text-gray-600 hover:bg-gray-100 transition-colors"
          >
            <i className="fas fa-minus text-sm"></i>
          </button>
          <span className="px-4 py-2 font-semibold text-gray-800 min-w-[40px] text-center">{quantity}</span>
          <button
            onClick={() => setQuantity(Math.min(product.stock_quantity, quantity + 1))}
            className="px-3 py-2 text-gray-600 hover:bg-gray-100 transition-colors"
          >
            <i className="fas fa-plus text-sm"></i>
          </button>
        </div>
        <button
          onClick={handleAdd}
          className="flex-1 py-3 rounded-lg text-white font-semibold transition-all hover:opacity-90 active:scale-95"
          style={{ backgroundColor: added ? "#059669" : primaryColor }}
        >
          {added ? (
            <><i className="fas fa-check mr-2"></i>কার্টে যোগ হয়েছে!</>
          ) : (
            <><i className="fas fa-shopping-cart mr-2"></i>কার্টে যোগ করুন</>
          )}
        </button>
      </div>
    </div>
  );
}
