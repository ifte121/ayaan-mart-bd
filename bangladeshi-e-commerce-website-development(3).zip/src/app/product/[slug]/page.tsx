import { db } from "@/db";
import { products, categories, reviews } from "@/db/schema";
import { eq, and, desc } from "drizzle-orm";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ProductCard from "@/components/ProductCard";
import { formatPrice } from "@/lib/auth";
import Link from "next/link";
import { notFound } from "next/navigation";
import AddToCartButton from "./AddToCartButton";
import ReviewForm from "./ReviewForm";
import { getLayoutData } from "@/lib/layout-data";

export const dynamic = "force-dynamic";

export default async function ProductDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;

  const { categories: allCategories, settings: settingsObj, currentUser } = await getLayoutData();

  const productData = await db.select().from(products).where(and(eq(products.slug, slug), eq(products.is_active, true))).limit(1);

  if (!productData[0]) notFound();

  const product = productData[0];

  let productReviews: (typeof reviews.$inferSelect)[] = [];
  let relatedProducts: (typeof products.$inferSelect)[] = [];
  let category: typeof categories.$inferSelect | undefined;

  try {
    const [reviewsResult, relatedResult, categoryResult] = await Promise.all([
      db
        .select()
        .from(reviews)
        .where(and(eq(reviews.product_id, product.id), eq(reviews.is_approved, true)))
        .orderBy(desc(reviews.created_at)),
      db
        .select()
        .from(products)
        .where(and(eq(products.category_id, product.category_id), eq(products.is_active, true)))
        .limit(5),
      db.select().from(categories).where(eq(categories.id, product.category_id)).limit(1),
    ]);
    productReviews = reviewsResult;
    relatedProducts = relatedResult;
    category = categoryResult[0];
  } catch (error) {
    console.error("[ProductDetailPage] Failed to load reviews/related products from database:", error);
  }

  const primaryColor = settingsObj.primary_color || "#dc2626";
  const images = product.images || (product.main_image ? [product.main_image] : []);
  const mainImage = product.main_image || "https://placehold.co/600x600/e2e8f0/333?text=No+Image";

  return (
    <>
      <Header categories={allCategories} settings={settingsObj} currentUser={currentUser} />

      <div className="bg-gray-50 min-h-screen">
        <div className="container-custom py-6">
          {/* Breadcrumb */}
          <div className="flex items-center gap-2 text-sm mb-6 flex-wrap">
            <Link href="/" className="text-gray-500 hover:text-primary">Home</Link>
            <i className="fas fa-chevron-right text-xs text-gray-400"></i>
            {category && (
              <>
                <Link href={`/category/${category.slug}`} className="text-gray-500 hover:text-primary">{category.name_bn}</Link>
                <i className="fas fa-chevron-right text-xs text-gray-400"></i>
              </>
            )}
            <span className="text-gray-800 font-medium truncate max-w-[200px]">{product.name_bn}</span>
          </div>

          <div className="bg-white rounded-2xl shadow-sm border overflow-hidden">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-0">
              {/* Image Gallery */}
              <div className="p-6 md:p-8 bg-gray-50">
                <div className="aspect-square rounded-xl overflow-hidden mb-4 border">
                  <img
                    id="main-image"
                    src={mainImage}
                    alt={product.name_bn}
                    className="w-full h-full object-cover"
                  />
                </div>
                {images.length > 1 && (
                  <div className="flex gap-2 overflow-x-auto">
                    {images.map((img: string, i: number) => (
                      <button
                        key={i}
                        className="w-16 h-16 rounded-lg border-2 overflow-hidden flex-shrink-0 border-gray-200"
                      >
                        <img src={img || "https://placehold.co/100x100/e2e8f0/333"} alt={`${product.name_bn} ${i + 1}`} className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Product Details */}
              <div className="p-6 md:p-8 flex flex-col">
                {/* Brand */}
                {product.brand && (
                  <span className="text-xs font-medium text-gray-500 uppercase tracking-wider mb-2">{product.brand}</span>
                )}

                <h1 className="text-xl md:text-2xl font-bold text-gray-800 mb-2">{product.name_bn}</h1>
                <p className="text-sm text-gray-500 mb-4">{product.name_en}</p>

                {/* SKU & Status */}
                <div className="flex items-center gap-3 mb-4 text-xs text-gray-500">
                  {product.sku && <span>SKU: {product.sku}</span>}
                  {product.stock_quantity > 0 ? (
                    <span className="text-green-600 flex items-center gap-1">
                      <i className="fas fa-circle text-[6px]"></i> স্টকে আছে ({product.stock_quantity})
                    </span>
                  ) : (
                    <span className="text-red-600">স্টক আউট</span>
                  )}
                </div>

                {/* Rating Summary */}
                <div className="flex items-center gap-2 mb-4">
                  <div className="flex items-center">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <i key={s} className={`fas fa-star text-sm ${s <= (productReviews.reduce((sum, r) => sum + r.rating, 0) / (productReviews.length || 1)) ? "text-yellow-400" : "text-gray-300"}`}></i>
                    ))}
                  </div>
                  <span className="text-sm text-gray-500">({productReviews.length} রিভিউ)</span>
                </div>

                {/* Price */}
                <div className="bg-gray-50 rounded-xl p-4 mb-6">
                  <div className="flex items-baseline gap-3">
                    <span className="sale-price text-3xl font-bold">{formatPrice(product.sale_price)}</span>
                    {product.discount_percent > 0 && (
                      <>
                        <span className="regular-price text-lg">{formatPrice(product.regular_price)}</span>
                        <span className="text-xs font-bold px-2 py-1 rounded-full text-white" style={{ backgroundColor: primaryColor }}>
                          -{product.discount_percent}% ছাড়
                        </span>
                      </>
                    )}
                  </div>
                  {product.discount_percent > 0 && (
                    <p className="text-sm text-green-600 mt-2">
                      আপনি বাঁচাচ্ছেন {formatPrice(parseFloat(product.regular_price) - parseFloat(product.sale_price))}!
                    </p>
                  )}
                </div>

                {/* Add to Cart */}
                {product.stock_quantity > 0 ? (
                  <AddToCartButton product={{
                    id: product.id,
                    name_bn: product.name_bn,
                    name_en: product.name_en,
                    sale_price: product.sale_price,
                    main_image: product.main_image,
                    stock_quantity: product.stock_quantity,
                  }} primaryColor={primaryColor} />
                ) : (
                  <button disabled className="w-full py-4 bg-gray-200 text-gray-500 rounded-xl font-semibold cursor-not-allowed mb-4">
                    স্টক আউট
                  </button>
                )}

                {/* Delivery Info */}
                <div className="border-t pt-4 mt-4 space-y-2 text-sm text-gray-600">
                  <p className="flex items-center gap-2">
                    <i className="fas fa-truck w-5 text-center" style={{ color: primaryColor }}></i>
                    ঢাকার ভিতরে ডেলিভারি: <span className="font-semibold">৳{settingsObj.delivery_inside_dhaka || "60"}</span>
                  </p>
                  <p className="flex items-center gap-2">
                    <i className="fas fa-map-pin w-5 text-center" style={{ color: primaryColor }}></i>
                    ঢাকার বাইরে ডেলিভারি: <span className="font-semibold">৳{settingsObj.delivery_outside_dhaka || "120"}</span>
                  </p>
                  <p className="flex items-center gap-2">
                    <i className="fas fa-undo w-5 text-center" style={{ color: primaryColor }}></i>
                    ৭ দিনের মধ্যে রিটার্ন নীতি
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Description & Reviews Tabs */}
          <div className="mt-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Description */}
            <div className="lg:col-span-2">
              <div className="bg-white rounded-xl shadow-sm border p-6 mb-6">
                <h2 className="text-xl font-bold text-gray-800 mb-4">পণ্যের বিবরণ</h2>
                <div className="prose prose-sm max-w-none text-gray-600" dangerouslySetInnerHTML={{ __html: product.description || "কোনো বিবরণ নেই।" }} />
              </div>

              {/* Reviews */}
              <div className="bg-white rounded-xl shadow-sm border p-6">
                <h2 className="text-xl font-bold text-gray-800 mb-4">
                  রিভিউ ({productReviews.length})
                </h2>

                {productReviews.length > 0 ? (
                  <div className="space-y-4 mb-6">
                    {productReviews.map((review) => (
                      <div key={review.id} className="border-b pb-4 last:border-0">
                        <div className="flex items-center gap-2 mb-1">
                          {[1, 2, 3, 4, 5].map((s) => (
                            <i key={s} className={`fas fa-star text-xs ${s <= review.rating ? "text-yellow-400" : "text-gray-300"}`}></i>
                          ))}
                        </div>
                        {review.comment && <p className="text-gray-600 text-sm">{review.comment}</p>}
                        <p className="text-xs text-gray-400 mt-1">{new Date(review.created_at).toLocaleDateString("bn-BD")}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500 text-sm mb-6">এখনো কোনো রিভিউ নেই। প্রথম রিভিউ দিন!</p>
                )}

                {currentUser ? (
                  <ReviewForm productId={product.id} />
                ) : (
                  <div className="bg-gray-50 p-4 rounded-lg text-center">
                    <p className="text-sm text-gray-500 mb-2">রিভিউ দিতে লগইন করুন</p>
                    <Link href="/login" className="btn-primary text-sm" style={{ backgroundColor: primaryColor }}>
                      লগইন
                    </Link>
                  </div>
                )}
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Payment Info */}
              <div className="bg-white rounded-xl shadow-sm border p-5">
                <h3 className="font-bold text-gray-800 mb-3">পেমেন্ট মাধ্যম</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2 text-gray-600">
                    <i className="fas fa-money-bill w-5 text-green-600"></i> ক্যাশ অন ডেলিভারি (COD)
                  </div>
                  <div className="flex items-center gap-2 text-gray-600">
                    <i className="fas fa-mobile-alt w-5 text-[#E2136E]"></i> bKash: {settingsObj.bkash_number}
                  </div>
                  <div className="flex items-center gap-2 text-gray-600">
                    <i className="fas fa-wallet w-5 text-[#F6921E]"></i> Nagad: {settingsObj.nagad_number}
                  </div>
                  <div className="flex items-center gap-2 text-gray-600">
                    <i className="fas fa-rocket w-5 text-[#8B2F87]"></i> Rocket: {settingsObj.rocket_number}
                  </div>
                </div>
              </div>

              {/* Need Help */}
              <div className="bg-white rounded-xl shadow-sm border p-5">
                <h3 className="font-bold text-gray-800 mb-3">সাহায্য দরকার?</h3>
                <div className="space-y-2 text-sm text-gray-600">
                  <a href={`tel:${settingsObj.contact_phone}`} className="flex items-center gap-2 hover:text-primary">
                    <i className="fas fa-phone w-5"></i> {settingsObj.contact_phone}
                  </a>
                  <a href={`https://wa.me/${(settingsObj.whatsapp_number || "+8801700000000").replace("+", "")}`} target="_blank" className="flex items-center gap-2 hover:text-primary">
                    <i className="fab fa-whatsapp w-5 text-green-500"></i> WhatsApp চ্যাট
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Related Products */}
          {relatedProducts.filter((p) => p.id !== product.id).length > 0 && (
            <section className="mt-12">
              <h2 className="text-2xl font-bold text-gray-800 mb-6">সম্পর্কিত পণ্য</h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                {relatedProducts.filter((p) => p.id !== product.id).map((p) => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </div>
            </section>
          )}
        </div>
      </div>

      <Footer settings={settingsObj} />
    </>
  );
}
