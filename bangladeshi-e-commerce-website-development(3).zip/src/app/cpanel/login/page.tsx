"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function AdminLoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();

      if (!data.success) {
        setError(data.error || "Login failed");
        setLoading(false);
        return;
      }

      if (data.user.role !== "admin") {
        // Not an admin account — clear the cookie and reject access
        document.cookie = "token=; path=/; max-age=0";
        setError("এই অ্যাকাউন্টটি Admin নয়। শুধুমাত্র Admin অ্যাকাউন্ট দিয়ে এখানে লগইন করা যাবে।");
        setLoading(false);
        return;
      }

      router.push("/cpanel");
      router.refresh();
    } catch {
      setError("Something went wrong. Please try again.");
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-dark flex items-center justify-center px-4">
      <div className="max-w-md w-full">
        <div className="text-center mb-8">
          <div className="text-3xl font-bold text-white mb-2">
            <i className="fas fa-shield-alt mr-2 text-red-500"></i>Ayaan Mart Admin
          </div>
          <p className="text-gray-400 text-sm">Secure Admin Panel Login</p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8">
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-600 rounded-lg p-3 mb-4 text-sm">
              <i className="fas fa-exclamation-circle mr-2"></i>{error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="form-label">Admin Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="form-input"
                placeholder="admin@ayaanmartbd.com"
                autoComplete="username"
              />
            </div>
            <div>
              <label className="form-label">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="form-input"
                placeholder="********"
                autoComplete="current-password"
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-red-600 text-white rounded-lg font-semibold hover:bg-red-700 transition-colors disabled:opacity-50"
            >
              {loading ? <i className="fas fa-spinner fa-spin mr-2"></i> : <i className="fas fa-lock mr-2"></i>}
              Admin Login
            </button>
          </form>

          <div className="mt-6 p-4 bg-gray-50 rounded-lg text-xs text-gray-500 text-center">
            <p className="font-medium mb-1">Default Admin Account:</p>
            <p>admin@ayaanmartbd.com / admin123</p>
          </div>
        </div>

        <p className="text-center text-gray-500 text-xs mt-6">
          <i className="fas fa-arrow-left mr-1"></i>
          <a href="/" className="hover:text-white">Back to Website</a>
        </p>
      </div>
    </div>
  );
}
