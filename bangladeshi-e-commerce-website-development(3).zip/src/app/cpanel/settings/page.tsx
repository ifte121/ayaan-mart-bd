"use client";
import { useState, useEffect } from "react";
import AdminGuard from "@/components/AdminGuard";

function SettingsContent() {
  const [settingsObj, setSettingsObj] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    fetch("/api/admin/settings")
      .then((r) => r.json())
      .then((d) => {
        setSettingsObj(d.settings || {});
        setLoading(false);
      });
  }, []);

  const handleSave = async () => {
    await fetch("/api/admin/settings", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ settings: settingsObj }) });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const update = (key: string, value: string) => {
    setSettingsObj({ ...settingsObj, [key]: value });
  };

  if (loading) {
    return (
      <div className="p-6 flex items-center justify-center">
        <div className="spinner"></div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-end items-center gap-3">
        {saved && (
          <span className="text-green-600 text-sm">
            <i className="fas fa-check mr-1"></i>Saved!
          </span>
        )}
        <button onClick={handleSave} className="btn-primary text-sm">
          <i className="fas fa-save mr-1"></i>Save Settings
        </button>
      </div>

      {/* General */}
      <div className="bg-white rounded-xl shadow-sm border p-6">
        <h2 className="font-bold text-lg mb-4">General Settings</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            { key: "site_name", label: "Site Name" },
            { key: "site_tagline", label: "Tagline" },
            { key: "contact_phone", label: "Phone" },
            { key: "contact_email", label: "Email" },
            { key: "contact_address", label: "Address" },
          ].map((f) => (
            <div key={f.key}>
              <label className="form-label">{f.label}</label>
              <input value={settingsObj[f.key] || ""} onChange={(e) => update(f.key, e.target.value)} className="form-input" />
            </div>
          ))}
        </div>
      </div>

      {/* Design */}
      <div className="bg-white rounded-xl shadow-sm border p-6">
        <h2 className="font-bold text-lg mb-4">Design Settings</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            { key: "primary_color", label: "Primary Color" },
            { key: "secondary_color", label: "Secondary Color" },
          ].map((f) => (
            <div key={f.key}>
              <label className="form-label">{f.label}</label>
              <div className="flex gap-2">
                <input type="color" value={settingsObj[f.key] || "#000"} onChange={(e) => update(f.key, e.target.value)} className="w-10 h-10 rounded border cursor-pointer" />
                <input value={settingsObj[f.key] || ""} onChange={(e) => update(f.key, e.target.value)} className="form-input flex-1" />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Payment */}
      <div className="bg-white rounded-xl shadow-sm border p-6">
        <h2 className="font-bold text-lg mb-4">Payment Numbers</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            { key: "bkash_number", label: "bKash Number" },
            { key: "nagad_number", label: "Nagad Number" },
            { key: "rocket_number", label: "Rocket Number" },
          ].map((f) => (
            <div key={f.key}>
              <label className="form-label">{f.label}</label>
              <input value={settingsObj[f.key] || ""} onChange={(e) => update(f.key, e.target.value)} className="form-input" />
            </div>
          ))}
        </div>
      </div>

      {/* Delivery */}
      <div className="bg-white rounded-xl shadow-sm border p-6">
        <h2 className="font-bold text-lg mb-4">Delivery Charges</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="form-label">Inside Dhaka (৳)</label>
            <input value={settingsObj.delivery_inside_dhaka || ""} onChange={(e) => update("delivery_inside_dhaka", e.target.value)} className="form-input" />
          </div>
          <div>
            <label className="form-label">Outside Dhaka (৳)</label>
            <input value={settingsObj.delivery_outside_dhaka || ""} onChange={(e) => update("delivery_outside_dhaka", e.target.value)} className="form-input" />
          </div>
        </div>
      </div>

      {/* Social */}
      <div className="bg-white rounded-xl shadow-sm border p-6">
        <h2 className="font-bold text-lg mb-4">Social Links</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            { key: "facebook_url", label: "Facebook URL" },
            { key: "instagram_url", label: "Instagram URL" },
            { key: "youtube_url", label: "YouTube URL" },
            { key: "whatsapp_number", label: "WhatsApp Number" },
          ].map((f) => (
            <div key={f.key}>
              <label className="form-label">{f.label}</label>
              <input value={settingsObj[f.key] || ""} onChange={(e) => update(f.key, e.target.value)} className="form-input" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default function AdminSettings() {
  return (
    <AdminGuard title="Settings">
      {() => <SettingsContent />}
    </AdminGuard>
  );
}
