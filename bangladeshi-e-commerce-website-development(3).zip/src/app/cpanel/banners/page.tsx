"use client";
import { useState, useEffect } from "react";
import AdminGuard from "@/components/AdminGuard";

function BannersContent() {
  const [banners, setBanners] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ title: "", image: "", link: "" });

  useEffect(() => {
    loadBanners();
  }, []);

  const loadBanners = () => {
    fetch("/api/admin/banners")
      .then((r) => r.json())
      .then((d) => {
        setBanners(d.banners || []);
        setLoading(false);
      });
  };

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    await fetch("/api/admin/banners", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    setShowAdd(false);
    setForm({ title: "", image: "", link: "" });
    loadBanners();
  };

  const toggleActive = async (id: number, current: boolean) => {
    await fetch("/api/admin/banners", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, is_active: !current }) });
    setBanners(banners.map((b) => (b.id === id ? { ...b, is_active: !current } : b)));
  };

  const deleteBanner = async (id: number) => {
    if (!confirm("Delete this banner?")) return;
    await fetch("/api/admin/banners", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id }) });
    setBanners(banners.filter((b) => b.id !== id));
  };

  if (loading) {
    return (
      <div className="p-6 flex items-center justify-center">
        <div className="spinner"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex justify-end mb-4">
        <button onClick={() => setShowAdd(!showAdd)} className="btn-primary text-sm">
          <i className="fas fa-plus mr-1"></i>Add Banner
        </button>
      </div>

      {showAdd && (
        <div className="bg-white rounded-xl shadow-sm border p-6 mb-6">
          <h2 className="font-bold mb-4">Add New Banner</h2>
          <form onSubmit={handleAdd} className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="form-label">Title</label>
              <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required className="form-input" />
            </div>
            <div>
              <label className="form-label">Image URL</label>
              <input value={form.image} onChange={(e) => setForm({ ...form, image: e.target.value })} required className="form-input" placeholder="https://placehold.co/1200x400" />
            </div>
            <div>
              <label className="form-label">Link (optional)</label>
              <input value={form.link} onChange={(e) => setForm({ ...form, link: e.target.value })} className="form-input" />
            </div>
            <button type="submit" className="btn-primary">
              Save Banner
            </button>
          </form>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {banners.map((b) => (
          <div key={b.id} className="bg-white rounded-xl shadow-sm border overflow-hidden">
            <img src={b.image} alt={b.title} className="w-full h-32 object-cover" />
            <div className="p-3">
              <h3 className="font-medium text-sm">{b.title}</h3>
              <p className="text-xs text-gray-400 truncate">{b.link || "-"}</p>
              <div className="flex gap-2 mt-2">
                <button
                  onClick={() => toggleActive(b.id, b.is_active)}
                  className={`text-xs px-2 py-1 rounded ${b.is_active ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}
                >
                  {b.is_active ? "Active" : "Inactive"}
                </button>
                <button onClick={() => deleteBanner(b.id)} className="text-xs px-2 py-1 rounded bg-red-50 text-red-600">
                  Delete
                </button>
              </div>
            </div>
          </div>
        ))}
        {banners.length === 0 && <div className="col-span-full text-center py-8 text-gray-400">No banners yet</div>}
      </div>
    </div>
  );
}

export default function AdminBanners() {
  return (
    <AdminGuard title="Banners">
      {() => <BannersContent />}
    </AdminGuard>
  );
}
