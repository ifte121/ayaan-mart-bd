"use client";
import { useState, useEffect } from "react";
import AdminGuard from "@/components/AdminGuard";

function ProductsContent() {
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/admin/products")
      .then((r) => r.json())
      .then((d) => {
        setProducts(d.products || []);
        setLoading(false);
      });
  }, []);

  const toggleStatus = async (id: number, currentStatus: string) => {
    const newStatus = currentStatus === "active" ? "inactive" : "active";
    await fetch("/api/admin/products", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, status: newStatus }),
    });
    setProducts(products.map((p) => (p.id === id ? { ...p, status: newStatus, is_active: newStatus !== "inactive" } : p)));
  };

  const deleteProduct = async (id: number) => {
    if (!confirm("Delete this product?")) return;
    await fetch("/api/admin/products", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id }) });
    setProducts(products.filter((p) => p.id !== id));
  };

  if (loading) {
    return (
      <div className="p-6 flex items-center justify-center">
        <div className="spinner"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="bg-white rounded-xl shadow-sm border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 text-gray-500">
              <tr>
                <th className="px-4 py-3 text-left">Name (BN)</th>
                <th className="px-4 py-3 text-left">Price</th>
                <th className="px-4 py-3 text-left">Stock</th>
                <th className="px-4 py-3 text-left">Status</th>
                <th className="px-4 py-3 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {products.map((p) => (
                <tr key={p.id} className="border-t">
                  <td className="px-4 py-3 font-medium">{p.name_bn}</td>
                  <td className="px-4 py-3">
                    <span className="font-bold">৳{parseInt(p.sale_price).toLocaleString("en-BD")}</span>
                    {p.discount_percent > 0 && (
                      <span className="text-xs text-gray-400 line-through ml-2">৳{parseInt(p.regular_price).toLocaleString("en-BD")}</span>
                    )}
                  </td>
                  <td className="px-4 py-3">{p.stock_quantity}</td>
                  <td className="px-4 py-3">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${p.status === "active" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}>
                      {p.status}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex gap-2">
                      <button
                        onClick={() => toggleStatus(p.id, p.status)}
                        className={`text-xs px-2 py-1 rounded ${p.status === "active" ? "bg-red-50 text-red-600" : "bg-green-50 text-green-600"}`}
                      >
                        {p.status === "active" ? "Deactivate" : "Activate"}
                      </button>
                      <button onClick={() => deleteProduct(p.id)} className="text-xs px-2 py-1 rounded bg-red-50 text-red-600">
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {products.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-gray-400">
                    No products yet
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default function AdminProducts() {
  return (
    <AdminGuard title="Products">
      {() => <ProductsContent />}
    </AdminGuard>
  );
}
