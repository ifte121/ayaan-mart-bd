"use client";
import { useState, useEffect } from "react";
import AdminGuard from "@/components/AdminGuard";

function CategoriesContent() {
  const [categories, setCategories] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ name_bn: "", name_en: "", icon: "", parent_id: "" });

  useEffect(() => {
    loadCategories();
  }, []);

  const loadCategories = () => {
    fetch("/api/admin/categories")
      .then((r) => r.json())
      .then((d) => {
        setCategories(d.categories || []);
        setLoading(false);
      });
  };

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    await fetch("/api/admin/categories", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name_bn: form.name_bn, name_en: form.name_en, icon: form.icon || null, parent_id: form.parent_id ? parseInt(form.parent_id) : null }),
    });
    setShowAdd(false);
    setForm({ name_bn: "", name_en: "", icon: "", parent_id: "" });
    loadCategories();
  };

  const toggleActive = async (id: number, current: boolean) => {
    await fetch("/api/admin/categories", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, is_active: !current }) });
    setCategories(categories.map((c) => (c.id === id ? { ...c, is_active: !current } : c)));
  };

  const deleteCategory = async (id: number) => {
    if (!confirm("Delete this category?")) return;
    await fetch("/api/admin/categories", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id }) });
    setCategories(categories.filter((c) => c.id !== id));
  };

  const parentCategories = categories.filter((c) => c.parent_id === null);

  if (loading) {
    return (
      <div className="p-6 flex items-center justify-center">
        <div className="spinner"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex justify-end mb-4">
        <button onClick={() => setShowAdd(!showAdd)} className="btn-primary text-sm">
          <i className="fas fa-plus mr-1"></i>Add Category
        </button>
      </div>

      {showAdd && (
        <div className="bg-white rounded-xl shadow-sm border p-6 mb-6">
          <h2 className="font-bold mb-4">Add New Category</h2>
          <form onSubmit={handleAdd} className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="form-label">Name (Bengali)</label>
              <input value={form.name_bn} onChange={(e) => setForm({ ...form, name_bn: e.target.value })} required className="form-input" />
            </div>
            <div>
              <label className="form-label">Name (English)</label>
              <input value={form.name_en} onChange={(e) => setForm({ ...form, name_en: e.target.value })} required className="form-input" />
            </div>
            <div>
              <label className="form-label">Icon (Font Awesome)</label>
              <input value={form.icon} onChange={(e) => setForm({ ...form, icon: e.target.value })} className="form-input" placeholder="fa-mobile" />
            </div>
            <div>
              <label className="form-label">Parent Category</label>
              <select value={form.parent_id} onChange={(e) => setForm({ ...form, parent_id: e.target.value })} className="form-input">
                <option value="">None (Main Category)</option>
                {parentCategories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name_bn}
                  </option>
                ))}
              </select>
            </div>
            <button type="submit" className="btn-primary">
              Save Category
            </button>
          </form>
        </div>
      )}

      <div className="bg-white rounded-xl shadow-sm border overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 text-gray-500">
            <tr>
              <th className="px-4 py-3 text-left">Name</th>
              <th className="px-4 py-3 text-left">Slug</th>
              <th className="px-4 py-3 text-left">Parent</th>
              <th className="px-4 py-3 text-left">Active</th>
              <th className="px-4 py-3 text-left">Action</th>
            </tr>
          </thead>
          <tbody>
            {categories.map((c) => (
              <tr key={c.id} className="border-t">
                <td className="px-4 py-3 font-medium">
                  {c.name_bn} <span className="text-gray-400 text-xs">({c.name_en})</span>
                </td>
                <td className="px-4 py-3 text-xs text-gray-500">{c.slug}</td>
                <td className="px-4 py-3 text-xs">{c.parent_id ? categories.find((p) => p.id === c.parent_id)?.name_bn || "-" : "Main"}</td>
                <td className="px-4 py-3">
                  <button
                    onClick={() => toggleActive(c.id, c.is_active)}
                    className={`text-xs px-2 py-0.5 rounded ${c.is_active ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}
                  >
                    {c.is_active ? "Yes" : "No"}
                  </button>
                </td>
                <td className="px-4 py-3">
                  <button onClick={() => deleteCategory(c.id)} className="text-xs px-2 py-1 rounded bg-red-50 text-red-600">
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default function AdminCategories() {
  return (
    <AdminGuard title="Categories">
      {() => <CategoriesContent />}
    </AdminGuard>
  );
}
