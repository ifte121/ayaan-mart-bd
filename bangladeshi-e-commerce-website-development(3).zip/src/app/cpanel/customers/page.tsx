"use client";
import { useState, useEffect } from "react";
import AdminGuard from "@/components/AdminGuard";

function CustomersContent() {
  const [customers, setCustomers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/admin/customers")
      .then((r) => r.json())
      .then((d) => {
        setCustomers(d.customers || []);
        setLoading(false);
      });
  }, []);

  const toggleBlock = async (id: number, current: boolean) => {
    await fetch("/api/admin/customers", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, is_blocked: !current }) });
    setCustomers(customers.map((c) => (c.id === id ? { ...c, is_blocked: !current } : c)));
  };

  if (loading) {
    return (
      <div className="p-6 flex items-center justify-center">
        <div className="spinner"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="bg-white rounded-xl shadow-sm border overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 text-gray-500">
            <tr>
              <th className="px-4 py-3 text-left">Name</th>
              <th className="px-4 py-3 text-left">Email</th>
              <th className="px-4 py-3 text-left">Phone</th>
              <th className="px-4 py-3 text-left">Verified</th>
              <th className="px-4 py-3 text-left">Status</th>
              <th className="px-4 py-3 text-left">Action</th>
            </tr>
          </thead>
          <tbody>
            {customers.map((c) => (
              <tr key={c.id} className="border-t">
                <td className="px-4 py-3 font-medium">{c.name}</td>
                <td className="px-4 py-3 text-xs">{c.email}</td>
                <td className="px-4 py-3 text-xs">{c.phone || "-"}</td>
                <td className="px-4 py-3">
                  <span className={`text-xs px-2 py-0.5 rounded-full ${c.is_verified ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"}`}>
                    {c.is_verified ? "Verified" : "Pending"}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <span className={`text-xs px-2 py-0.5 rounded-full ${c.is_blocked ? "bg-red-100 text-red-700" : "bg-green-100 text-green-700"}`}>
                    {c.is_blocked ? "Blocked" : "Active"}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <button
                    onClick={() => toggleBlock(c.id, c.is_blocked)}
                    className={`text-xs px-2 py-1 rounded ${c.is_blocked ? "bg-green-50 text-green-600" : "bg-red-50 text-red-600"}`}
                  >
                    {c.is_blocked ? "Unblock" : "Block"}
                  </button>
                </td>
              </tr>
            ))}
            {customers.length === 0 && (
              <tr>
                <td colSpan={6} className="py-8 text-center text-gray-400">
                  No customers yet
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default function AdminCustomers() {
  return (
    <AdminGuard title="Customers">
      {() => <CustomersContent />}
    </AdminGuard>
  );
}
