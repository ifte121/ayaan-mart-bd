"use client";
import { useState, useEffect } from "react";
import AdminGuard from "@/components/AdminGuard";

function DashboardContent() {
  const [stats, setStats] = useState<any>(null);
  const [recentOrders, setRecentOrders] = useState<any[]>([]);
  const [lowStock, setLowStock] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/admin/stats")
      .then((r) => r.json())
      .then((data) => {
        setStats(data.stats);
        setRecentOrders(data.recentOrders || []);
        setLowStock(data.lowStock || []);
        setLoading(false);
      });
  }, []);

  const formatTk = (val: number) => "৳" + (val || 0).toLocaleString("en-BD");

  if (loading) {
    return (
      <div className="p-6 flex items-center justify-center">
        <div className="spinner"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {[
          { label: "Today's Orders", value: stats?.todayOrders || 0, color: "#3b82f6", icon: "fa-shopping-cart" },
          { label: "Today's Revenue", value: formatTk(stats?.todayRevenue || 0), color: "#059669", icon: "fa-money-bill" },
          { label: "Pending Orders", value: stats?.pendingOrders || 0, color: "#f59e0b", icon: "fa-clock" },
          { label: "Total Products", value: stats?.totalProducts || 0, color: "#8b5cf6", icon: "fa-box" },
        ].map((s, i) => (
          <div key={i} className="bg-white rounded-xl shadow-sm border p-5">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-lg flex items-center justify-center text-white" style={{ backgroundColor: s.color }}>
                <i className={`fas ${s.icon}`}></i>
              </div>
              <span className="text-sm text-gray-500">{s.label}</span>
            </div>
            <div className="text-2xl font-bold">{s.value}</div>
          </div>
        ))}
      </div>

      {/* More stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {[
          { label: "Total Orders", value: stats?.totalOrders || 0 },
          { label: "Total Revenue", value: formatTk(stats?.totalRevenue || 0) },
          { label: "Total Customers", value: stats?.totalCustomers || 0 },
          { label: "Week Orders", value: stats?.weekOrders || 0 },
        ].map((s, i) => (
          <div key={i} className="bg-white rounded-xl shadow-sm border p-4">
            <p className="text-xs text-gray-500">{s.label}</p>
            <p className="text-xl font-bold">{s.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Orders */}
        <div className="bg-white rounded-xl shadow-sm border p-5">
          <h2 className="font-bold text-lg mb-4">Recent Orders</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-gray-500 border-b">
                  <th className="pb-2">Order #</th>
                  <th className="pb-2">Customer</th>
                  <th className="pb-2">Total</th>
                  <th className="pb-2">Status</th>
                </tr>
              </thead>
              <tbody>
                {recentOrders.map((order: any) => (
                  <tr key={order.id} className="border-b last:border-0">
                    <td className="py-2 font-medium">#{order.order_number}</td>
                    <td className="py-2">{order.customer_name}</td>
                    <td className="py-2">৳{parseInt(order.total).toLocaleString("en-BD")}</td>
                    <td className="py-2">
                      <span
                        className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                          order.order_status === "pending"
                            ? "bg-yellow-100 text-yellow-700"
                            : order.order_status === "processing"
                            ? "bg-blue-100 text-blue-700"
                            : order.order_status === "shipped"
                            ? "bg-purple-100 text-purple-700"
                            : order.order_status === "delivered"
                            ? "bg-green-100 text-green-700"
                            : "bg-red-100 text-red-700"
                        }`}
                      >
                        {order.order_status}
                      </span>
                    </td>
                  </tr>
                ))}
                {recentOrders.length === 0 && (
                  <tr>
                    <td colSpan={4} className="py-4 text-center text-gray-400">
                      No orders yet
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Low Stock Alerts */}
        <div className="bg-white rounded-xl shadow-sm border p-5">
          <h2 className="font-bold text-lg mb-4">Low Stock Alerts</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-gray-500 border-b">
                  <th className="pb-2">Product</th>
                  <th className="pb-2">Stock</th>
                  <th className="pb-2">Price</th>
                </tr>
              </thead>
              <tbody>
                {lowStock.map((p: any) => (
                  <tr key={p.id} className="border-b last:border-0">
                    <td className="py-2">{p.name_bn}</td>
                    <td className="py-2">
                      <span className="text-red-600 font-bold">{p.stock_quantity}</span>
                    </td>
                    <td className="py-2">৳{parseInt(p.sale_price).toLocaleString("en-BD")}</td>
                  </tr>
                ))}
                {lowStock.length === 0 && (
                  <tr>
                    <td colSpan={3} className="py-4 text-center text-gray-400">
                      All products in stock
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function AdminDashboard() {
  return (
    <AdminGuard title="Dashboard">
      {() => <DashboardContent />}
    </AdminGuard>
  );
}
