"use client";
import { useState, useEffect } from "react";
import AdminGuard from "@/components/AdminGuard";

function CouponsContent() {
  const [coupons, setCoupons] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ code: "", description: "", discount_type: "percentage", discount_value: "", min_order_amount: "0", max_usage: "0" });

  useEffect(() => {
    loadCoupons();
  }, []);

  const loadCoupons = () => {
    fetch("/api/admin/coupons")
      .then((r) => r.json())
      .then((d) => {
        setCoupons(d.coupons || []);
        setLoading(false);
      });
  };

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    await fetch("/api/admin/coupons", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    setShowAdd(false);
    setForm({ code: "", description: "", discount_type: "percentage", discount_value: "", min_order_amount: "0", max_usage: "0" });
    loadCoupons();
  };

  const toggleActive = async (id: number, current: boolean) => {
    await fetch("/api/admin/coupons", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, is_active: !current }) });
    setCoupons(coupons.map((c) => (c.id === id ? { ...c, is_active: !current } : c)));
  };

  const deleteCoupon = async (id: number) => {
    if (!confirm("Delete this coupon?")) return;
    await fetch("/api/admin/coupons", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id }) });
    setCoupons(coupons.filter((c) => c.id !== id));
  };

  if (loading) {
    return (
      <div className="p-6 flex items-center justify-center">
        <div className="spinner"></div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex justify-end mb-4">
        <button onClick={() => setShowAdd(!showAdd)} className="btn-primary text-sm">
          <i className="fas fa-plus mr-1"></i>Add Coupon
        </button>
      </div>

      {showAdd && (
        <div className="bg-white rounded-xl shadow-sm border p-6 mb-6">
          <h2 className="font-bold mb-4">Add New Coupon</h2>
          <form onSubmit={handleAdd} className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="form-label">Code</label>
              <input value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} required className="form-input" />
            </div>
            <div>
              <label className="form-label">Type</label>
              <select value={form.discount_type} onChange={(e) => setForm({ ...form, discount_type: e.target.value })} className="form-input">
                <option value="percentage">Percentage</option>
                <option value="fixed">Fixed Amount</option>
              </select>
            </div>
            <div>
              <label className="form-label">Value</label>
              <input type="number" value={form.discount_value} onChange={(e) => setForm({ ...form, discount_value: e.target.value })} required className="form-input" />
            </div>
            <div>
              <label className="form-label">Min Order Amount</label>
              <input type="number" value={form.min_order_amount} onChange={(e) => setForm({ ...form, min_order_amount: e.target.value })} className="form-input" />
            </div>
            <div>
              <label className="form-label">Max Usage</label>
              <input type="number" value={form.max_usage} onChange={(e) => setForm({ ...form, max_usage: e.target.value })} className="form-input" />
            </div>
            <button type="submit" className="btn-primary self-end">
              Save Coupon
            </button>
          </form>
        </div>
      )}

      <div className="bg-white rounded-xl shadow-sm border overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 text-gray-500">
            <tr>
              <th className="px-4 py-3 text-left">Code</th>
              <th className="px-4 py-3 text-left">Type</th>
              <th className="px-4 py-3 text-left">Value</th>
              <th className="px-4 py-3 text-left">Used</th>
              <th className="px-4 py-3 text-left">Active</th>
              <th className="px-4 py-3 text-left">Action</th>
            </tr>
          </thead>
          <tbody>
            {coupons.map((c) => (
              <tr key={c.id} className="border-t">
                <td className="px-4 py-3 font-bold">{c.code}</td>
                <td className="px-4 py-3 text-xs">{c.discount_type}</td>
                <td className="px-4 py-3">{c.discount_type === "percentage" ? `${c.discount_value}%` : `৳${c.discount_value}`}</td>
                <td className="px-4 py-3 text-xs">
                  {c.used_count}/{c.max_usage || "∞"}
                </td>
                <td className="px-4 py-3">
                  <button
                    onClick={() => toggleActive(c.id, c.is_active)}
                    className={`text-xs px-2 py-0.5 rounded ${c.is_active ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}
                  >
                    {c.is_active ? "Yes" : "No"}
                  </button>
                </td>
                <td className="px-4 py-3">
                  <button onClick={() => deleteCoupon(c.id)} className="text-xs px-2 py-1 rounded bg-red-50 text-red-600">
                    Delete
                  </button>
                </td>
              </tr>
            ))}
            {coupons.length === 0 && (
              <tr>
                <td colSpan={6} className="py-8 text-center text-gray-400">
                  No coupons yet
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default function AdminCoupons() {
  return (
    <AdminGuard title="Coupons">
      {() => <CouponsContent />}
    </AdminGuard>
  );
}
