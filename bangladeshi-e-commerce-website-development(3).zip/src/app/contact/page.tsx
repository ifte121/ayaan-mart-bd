import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { getLayoutData } from "@/lib/layout-data";

export const dynamic = "force-dynamic";

export default async function ContactPage() {
  const { categories: allCategories, settings: settingsObj, currentUser } = await getLayoutData();

  return (
    <>
      <Header categories={allCategories} settings={settingsObj} currentUser={currentUser} />
      <div className="bg-gray-50 min-h-screen py-12">
        <div className="container-custom max-w-4xl">
          <h1 className="text-3xl font-bold text-gray-800 mb-8">যোগাযোগ করুন</h1>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white rounded-2xl shadow-sm border p-6">
              <h2 className="text-xl font-bold mb-4">আমাদের ঠিকানা</h2>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center text-primary"><i className="fas fa-map-marker-alt"></i></div>
                  <div><p className="font-medium">ঠিকানা</p><p className="text-sm text-gray-500">{settingsObj.contact_address || "Dhaka, Bangladesh"}</p></div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center text-primary"><i className="fas fa-phone"></i></div>
                  <div><p className="font-medium">ফোন</p><a href={`tel:${settingsObj.contact_phone}`} className="text-sm text-primary">{settingsObj.contact_phone || "+8801700000000"}</a></div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center text-primary"><i className="fas fa-envelope"></i></div>
                  <div><p className="font-medium">ইমেইল</p><a href={`mailto:${settingsObj.contact_email}`} className="text-sm text-primary">{settingsObj.contact_email || "info@ayaanmartbd.com"}</a></div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center text-green-500"><i className="fab fa-whatsapp"></i></div>
                  <div><p className="font-medium">WhatsApp</p><a href={`https://wa.me/${(settingsObj.whatsapp_number || "+8801700000000").replace("+", "")}`} target="_blank" className="text-sm text-green-600">WhatsApp এ চ্যাট করুন</a></div>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-2xl shadow-sm border p-6">
              <h2 className="text-xl font-bold mb-4">মেসেজ পাঠান</h2>
              <form className="space-y-3">
                <input type="text" placeholder="আপনার নাম" className="form-input" required />
                <input type="email" placeholder="ইমেইল" className="form-input" required />
                <input type="tel" placeholder="ফোন নাম্বার" className="form-input" />
                <textarea placeholder="আপনার মেসেজ লিখুন..." rows={4} className="form-input" required></textarea>
                <button type="submit" className="btn-primary w-full">মেসেজ পাঠান</button>
              </form>
            </div>
          </div>
        </div>
      </div>
      <Footer settings={settingsObj} />
    </>
  );
}
