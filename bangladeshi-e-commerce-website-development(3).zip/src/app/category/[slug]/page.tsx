import { db } from "@/db";
import { products, categories } from "@/db/schema";
import { eq, and, desc, sql } from "drizzle-orm";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ProductCard from "@/components/ProductCard";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getLayoutData } from "@/lib/layout-data";

export const dynamic = "force-dynamic";

export default async function CategoryPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const { categories: allCategories, settings: settingsObj, currentUser } = await getLayoutData();

  // Find category
  const [category] = await db.select().from(categories).where(eq(categories.slug, slug)).limit(1);
  if (!category) notFound();

  // Get all child category IDs
  const childCategories = allCategories.filter((c) => c.parent_id === category.id);
  const allCategoryIds = [category.id, ...childCategories.map((c) => c.id)];

  // Get products
  let catProducts: (typeof products.$inferSelect)[] = [];
  try {
    catProducts = await db.select().from(products).where(
      and(eq(products.is_active, true), sql`${products.category_id} IN (${allCategoryIds.join(",")})`)
    ).orderBy(desc(products.created_at)).limit(24);
  } catch (error) {
    console.error("[CategoryPage] Failed to load products from database:", error);
  }

  const primaryColor = settingsObj.primary_color || "#dc2626";

  return (
    <>
      <Header categories={allCategories} settings={settingsObj} currentUser={currentUser} />
      <div className="bg-gray-50 min-h-screen py-6">
        <div className="container-custom">
          <div className="flex items-center gap-2 text-sm mb-6">
            <Link href="/" className="text-gray-500 hover:text-primary">Home</Link>
            <i className="fas fa-chevron-right text-xs text-gray-400"></i>
            <span className="text-gray-800 font-medium">{category.name_bn}</span>
          </div>

          <div className="mb-6">
            <h1 className="text-2xl font-bold text-gray-800">{category.name_bn}</h1>
            {childCategories.length > 0 && (
              <div className="flex gap-2 mt-3 flex-wrap">
                {childCategories.map((sub) => (
                  <Link key={sub.id} href={`/category/${sub.slug}`} className="px-4 py-1.5 rounded-full text-sm border hover:border-primary hover:text-primary transition-colors">
                    {sub.name_bn}
                  </Link>
                ))}
              </div>
            )}
          </div>

          {catProducts.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {catProducts.map((p) => <ProductCard key={p.id} product={p} />)}
            </div>
          ) : (
            <div className="bg-white rounded-xl border p-12 text-center">
              <div className="text-6xl mb-4">📦</div>
              <h3 className="text-xl font-bold">কোনো পণ্য পাওয়া যায়নি</h3>
              <p className="text-gray-500">এই ক্যাটাগরিতে এখনো কোনো পণ্য নেই।</p>
            </div>
          )}
        </div>
      </div>
      <Footer settings={settingsObj} />
    </>
  );
}
