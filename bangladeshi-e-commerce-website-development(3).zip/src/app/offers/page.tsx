import { db } from "@/db";
import { products } from "@/db/schema";
import { eq, and, desc } from "drizzle-orm";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ProductCard from "@/components/ProductCard";
import { getLayoutData } from "@/lib/layout-data";

export const dynamic = "force-dynamic";

export default async function OffersPage() {
  const { categories: allCategories, settings: settingsObj, currentUser } = await getLayoutData();

  let discountedProducts: (typeof products.$inferSelect)[] = [];
  try {
    discountedProducts = await db.select().from(products).where(and(eq(products.is_active, true))).orderBy(desc(products.discount_percent)).limit(12);
  } catch (error) {
    console.error("[OffersPage] Failed to load products from database:", error);
  }

  return (
    <>
      <Header categories={allCategories} settings={settingsObj} currentUser={currentUser} />
      <div className="bg-gray-50 min-h-screen py-8">
        <div className="container-custom">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-800"><i className="fas fa-fire text-primary mr-2"></i>অফার ও ডিল</h1>
            <p className="text-gray-500 mt-2">বিশেষ ছাড়ের পণ্য সমূহ</p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {discountedProducts.filter((p) => p.discount_percent > 0).map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      </div>
      <Footer settings={settingsObj} />
    </>
  );
}
