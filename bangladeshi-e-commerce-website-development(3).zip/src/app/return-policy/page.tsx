import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { getLayoutData } from "@/lib/layout-data";

export const dynamic = "force-dynamic";

export default async function ReturnPolicyPage() {
  const { categories: allCategories, settings: settingsObj, currentUser } = await getLayoutData();

  return (
    <>
      <Header categories={allCategories} settings={settingsObj} currentUser={currentUser} />
      <div className="bg-gray-50 min-h-screen py-12">
        <div className="container-custom max-w-4xl">
          <h1 className="text-3xl font-bold text-gray-800 mb-8">রিটার্ন ও রিফান্ড পলিসি</h1>
          <div className="bg-white rounded-2xl shadow-sm border p-8 prose prose-sm max-w-none">
            <p>আমাদের রিটার্ন পলিসি ৭ দিনের। ক্রয়ের ৭ দিনের মধ্যে আপনি পণ্য রিটার্ন করতে পারবেন।</p>
            <h2>রিটার্ন করার শর্তাবলী</h2><ul><li>পণ্যটি অব্যবহৃত ও আসল অবস্থায় থাকতে হবে</li><li>পণ্যের সাথে মূল প্যাকেজিং থাকতে হবে</li><li>রিসিপ্ট বা প্রমাণ থাকতে হবে</li></ul>
            <h2>রিফান্ড</h2><p>রিটার্ন গৃহীত হওয়ার পর ৭-১৪ কার্যদিবসের মধ্যে রিফান্ড প্রদান করা হবে।</p>
          </div>
        </div>
      </div>
      <Footer settings={settingsObj} />
    </>
  );
}
