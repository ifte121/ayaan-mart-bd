import { db } from "@/db";
import { products, banners } from "@/db/schema";
import { eq, and, desc } from "drizzle-orm";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ProductCard from "@/components/ProductCard";
import Link from "next/link";
import { getLayoutData } from "@/lib/layout-data";

// Force dynamic rendering: this page reads from the database (products,
// banners, categories, settings) and the current user's session, so it must
// never be statically prerendered at build time.
export const dynamic = "force-dynamic";

export default async function HomePage() {
  const { categories: allCategories, settings: settingsObj, currentUser } = await getLayoutData();

  let featuredProducts: (typeof products.$inferSelect)[] = [];
  let newArrivals: (typeof products.$inferSelect)[] = [];
  let allBanners: (typeof banners.$inferSelect)[] = [];
  let spotlightProduct: typeof products.$inferSelect | null = null;

  try {
    const [featuredResult, newArrivalsResult, bannersResult, highlightResult] = await Promise.all([
      db.select().from(products).where(and(eq(products.is_active, true), eq(products.is_featured, true))).orderBy(desc(products.discount_percent)).limit(8),
      db.select().from(products).where(and(eq(products.is_active, true), eq(products.is_new_arrival, true))).orderBy(desc(products.created_at)).limit(8),
      db.select().from(banners).where(eq(banners.is_active, true)).orderBy(banners.sort_order),
      db.select().from(products).where(eq(products.slug, "kids-blazer-suit-set")).limit(1),
    ]);
    featuredProducts = featuredResult;
    newArrivals = newArrivalsResult;
    allBanners = bannersResult;
    spotlightProduct = highlightResult[0] || null;
  } catch (error) {
    console.error("[HomePage] Failed to load products/banners from database:", error);
  }

  const primaryColor = settingsObj.primary_color || "#dc2626";
  const secondaryColor = settingsObj.secondary_color || "#059669";

  const parentCategories = allCategories.filter((c) => c.parent_id === null);

  return (
    <>
      <Header categories={allCategories} settings={settingsObj} currentUser={currentUser} />

      {/* Hero Banner Slider */}
      <section className="mb-8">
        {allBanners.length > 0 ? (
          <div className="banner-slider relative w-full" style={{ height: "400px" }}>
            <img
              src={allBanners[0].image}
              alt={allBanners[0].title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-transparent flex items-center">
              <div className="container-custom">
                <h1
                  className="text-3xl md:text-5xl font-bold text-white mb-4 max-w-xl"
                  style={{ fontFamily: "'Hind Siliguri', sans-serif" }}
                >
                  {allBanners[0].title}
                </h1>
                <Link
                  href={allBanners[0].link || "/shop"}
                  className="inline-block px-8 py-3 rounded-lg text-white font-semibold text-lg transition-all hover:opacity-90"
                  style={{ backgroundColor: primaryColor }}
                >
                  এখনই কিনুন <i className="fas fa-arrow-right ml-2"></i>
                </Link>
              </div>
            </div>
            {/* Dots */}
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
              {allBanners.map((_, i) => (
                <button
                  key={i}
                  className={`w-3 h-3 rounded-full transition-all ${i === 0 ? "bg-white w-8" : "bg-white/50"}`}
                />
              ))}
            </div>
          </div>
        ) : (
          <div className="bg-gradient-to-r from-primary to-red-800 text-white py-20 text-center">
            <h1 className="text-4xl font-bold mb-4">Ayaan Mart BD</h1>
            <p className="text-xl">আপনার বিশ্বস্ত অনলাইন শপ</p>
          </div>
        )}
      </section>

      {/* Special Spotlight Product - Kids Blazer Highlight */}
      {spotlightProduct && (
        <section className="container-custom mb-10">
          <div className="relative rounded-2xl overflow-hidden shadow-xl border-2" style={{ borderColor: primaryColor }}>
            <div className="absolute top-4 left-4 z-10">
              <span className="inline-flex items-center gap-1 bg-yellow-400 text-yellow-900 text-xs font-bold px-3 py-1.5 rounded-full animate-pulse-slow shadow-md">
                <i className="fas fa-star"></i> স্পেশাল হাইলাইট
              </span>
            </div>
            <Link href={`/product/${spotlightProduct.slug}`} className="grid grid-cols-1 md:grid-cols-2 bg-white">
              <div className="bg-gray-50 flex items-center justify-center p-6">
                <img
                  src={spotlightProduct.main_image || "https://placehold.co/500x500"}
                  alt={spotlightProduct.name_bn}
                  className="max-h-96 w-auto object-contain rounded-xl"
                />
              </div>
              <div className="p-8 flex flex-col justify-center">
                <span className="text-xs font-semibold uppercase tracking-wider mb-2" style={{ color: primaryColor }}>
                  <i className="fas fa-crown mr-1"></i> Kids Collection
                </span>
                <h2 className="text-2xl md:text-3xl font-bold text-gray-800 mb-3">{spotlightProduct.name_bn}</h2>
                <p className="text-gray-500 mb-4 hidden md:block">{spotlightProduct.name_en} — বিশেষ অনুষ্ঠান, পার্টি ও ঈদের জন্য পারফেক্ট ব্লেজার সেট!</p>

                <div className="flex items-baseline gap-3 mb-4">
                  <span className="text-3xl font-extrabold" style={{ color: primaryColor }}>
                    ৳{parseInt(spotlightProduct.sale_price).toLocaleString("en-BD")}
                  </span>
                  <span className="text-lg text-gray-400 line-through">
                    ৳{parseInt(spotlightProduct.regular_price).toLocaleString("en-BD")}
                  </span>
                  <span className="text-sm font-bold px-2 py-1 rounded-full text-white" style={{ backgroundColor: secondaryColor }}>
                    -{spotlightProduct.discount_percent}% ছাড়
                  </span>
                </div>

                <span
                  className="inline-block w-fit px-8 py-3 rounded-lg text-white font-semibold transition-all hover:opacity-90"
                  style={{ backgroundColor: primaryColor }}
                >
                  <i className="fas fa-shopping-bag mr-2"></i>এখনই দেখুন
                </span>
              </div>
            </Link>
          </div>
        </section>
      )}

      {/* Features Bar */}
      <section className="container-custom mb-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { icon: "fa-truck-fast", title: "ফ্রি ডেলিভারি", desc: "ঢাকার ভিতরে ৳৯৯৯+ অর্ডারে", color: secondaryColor },
            { icon: "fa-shield-halved", title: "নিরাপদ পেমেন্ট", desc: "ক্যাশ অন ডেলিভারি ও bKash", color: "#2563eb" },
            { icon: "fa-rotate-left", title: "সহজ রিটার্ন", desc: "৭ দিনের মধ্যে রিটার্ন নীতি", color: "#f59e0b" },
            { icon: "fa-headset", title: "২৪/৭ সাপোর্ট", desc: "সার্বক্ষণিক কাস্টমার সেবা", color: "#8b5cf6" },
          ].map((f, i) => (
            <div key={i} className="bg-white rounded-xl p-4 flex items-center gap-4 shadow-sm border">
              <div className="w-12 h-12 rounded-lg flex items-center justify-center text-white flex-shrink-0" style={{ backgroundColor: f.color }}>
                <i className={`fas ${f.icon} text-lg`}></i>
              </div>
              <div>
                <h3 className="font-semibold text-sm text-gray-800">{f.title}</h3>
                <p className="text-xs text-gray-500">{f.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Category Showcase */}
      <section className="container-custom mb-12">
        <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
          <i className="fas fa-th-large" style={{ color: primaryColor }}></i>
          ক্যাটাগরি
        </h2>
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-3">
          {parentCategories.map((cat) => (
            <Link
              key={cat.id}
              href={`/category/${cat.slug}`}
              className="flex flex-col items-center gap-2 p-4 bg-white rounded-xl border hover:shadow-md transition-all group"
            >
              <div
                className="w-14 h-14 rounded-full flex items-center justify-center text-xl transition-all group-hover:scale-110"
                style={{ backgroundColor: `${primaryColor}15`, color: primaryColor }}
              >
                {cat.icon ? <i className={`fas ${cat.icon}`}></i> : <i className="fas fa-box"></i>}
              </div>
              <span className="text-xs text-center text-gray-700 font-medium leading-tight">{cat.name_bn}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* FIX: Use featuredProducts length */}
      {featuredProducts.length > 0 && (
        <section className="container-custom mb-12">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
              <i className="fas fa-star" style={{ color: "#f59e0b" }}></i>
              ফিচার্ড পণ্য
            </h2>
            <Link href="/shop?featured=true" className="text-sm font-medium hover:underline" style={{ color: primaryColor }}>
              সব দেখুন <i className="fas fa-arrow-right ml-1 text-xs"></i>
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {featuredProducts.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      )}

      {/* New Arrivals */}
      {newArrivals.length > 0 && (
        <section className="container-custom mb-12">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
              <i className="fas fa-bolt" style={{ color: secondaryColor }}></i>
              নতুন এসেছে
            </h2>
            <Link href="/shop?new=true" className="text-sm font-medium hover:underline" style={{ color: primaryColor }}>
              সব দেখুন <i className="fas fa-arrow-right ml-1 text-xs"></i>
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {newArrivals.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      )}

      {/* Special Offer Banner */}
      <section className="container-custom mb-12">
        <div className="relative rounded-2xl overflow-hidden" style={{ backgroundColor: primaryColor }}>
          <div className="flex flex-col md:flex-row items-center justify-between p-8 md:p-12">
            <div className="text-white mb-6 md:mb-0 text-center md:text-left">
              <span className="inline-block bg-white/20 text-white text-sm px-3 py-1 rounded-full mb-3">
                সীমিত সময়ের অফার!
              </span>
              <h2 className="text-3xl md:text-4xl font-bold mb-2">৫০% পর্যন্ত ছাড়!</h2>
              <p className="text-white/80 text-lg mb-4">বেস্টসেলার প্রোডাক্ট গুলোতে বিশাল ছাড়। দেরি না করে এখনই অর্ডার করুন!</p>
              <Link
                href="/offers"
                className="inline-block bg-white px-8 py-3 rounded-lg font-bold text-lg transition-all hover:bg-gray-100"
                style={{ color: primaryColor }}
              >
                অফার দেখুন <i className="fas fa-arrow-right ml-2"></i>
              </Link>
            </div>
            <div className="text-center">
              <div className="w-32 h-32 md:w-40 md:h-40 bg-white/10 rounded-full flex items-center justify-center animate-pulse-slow">
                <div className="text-white text-center">
                  <div className="text-4xl md:text-5xl font-bold">50%</div>
                  <div className="text-sm">OFF</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="bg-white py-12 mb-12">
        <div className="container-custom">
          <h2 className="text-2xl font-bold text-center mb-8 text-gray-800">
            কেন <span style={{ color: primaryColor }}>Ayaan Mart</span> বেছে নিবেন?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {[
              { icon: "fa-tags", title: "সেরা দাম", desc: "আমরা বাজারের সেরা দামে পণ্য সরবরাহ করি। নিয়মিত অফার ও ডিসকাউন্ট উপভোগ করুন।" },
              { icon: "fa-box", title: "দ্রুত ডেলিভারি", desc: "ঢাকা শহরে ২৪-৪৮ ঘন্টার মধ্যে ডেলিভারি। সারা বাংলাদেশে দ্রুত ডেলিভারি সেবা।" },
              { icon: "fa-medal", title: "১০০% অরিজিনাল", desc: "আমাদের সব পণ্য ১০০% অরিজিনাল ও ওয়ারেন্টি সহ। নকল পণ্যের কোনো স্থান নেই।" },
            ].map((item, i) => (
              <div key={i} className="text-center">
                <div className="w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center text-2xl text-white" style={{ backgroundColor: primaryColor }}>
                  <i className={`fas ${item.icon}`}></i>
                </div>
                <h3 className="font-semibold text-lg mb-2">{item.title}</h3>
                <p className="text-gray-500 text-sm">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="container-custom mb-12">
        <h2 className="text-2xl font-bold text-center mb-8 text-gray-800">
          গ্রাহকদের <span style={{ color: primaryColor }}>মতামত</span>
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          {[
            { name: "রাফসান আহমেদ", text: "খুব ভালো সার্ভিস! প্রোডাক্ট কোয়ালিটি দারুণ, ডেলিভারি টাইম মতো হয়েছে। Ayaan Mart থেকে আবারো কেনাকাটা করবো। ⭐⭐⭐⭐⭐", city: "ঢাকা" },
            { name: "নুসরাত জাহান", text: "প্রথমবার অর্ডার করলাম, অনেক ভালো লেগেছে। প্রোডাক্ট এক্স্যাক্টলি ছবির মতোই ছিলো। ধন্যবাদ Ayaan Mart! ⭐⭐⭐⭐⭐", city: "চট্টগ্রাম" },
            { name: "মাহমুদ হাসান", text: "সাশ্রয়ী মূল্যে দুর্দান্ত সব পণ্য। bKash পেমেন্ট খুব সহজ ছিলো। সবার জন্য রেকমেন্ডেড! ⭐⭐⭐⭐", city: "সিলেট" },
          ].map((t, i) => (
            <div key={i} className="bg-white p-6 rounded-xl border shadow-sm">
              <div className="flex items-center gap-1 mb-3">
                {[1, 2, 3, 4, 5].map((s) => (
                  <i key={s} className="fas fa-star text-yellow-400 text-sm"></i>
                ))}
              </div>
              <p className="text-gray-600 text-sm mb-4 italic">"{t.text}"</p>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center text-gray-500 font-bold text-sm">
                  {t.name.charAt(0)}
                </div>
                <div>
                  <p className="font-medium text-sm text-gray-800">{t.name}</p>
                  <p className="text-xs text-gray-400">{t.city}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      <Footer settings={settingsObj} />
    </>
  );
}
