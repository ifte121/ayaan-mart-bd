"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import HeaderClient from "@/components/HeaderClient";
import FooterClient from "@/components/FooterClient";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (data.success) {
        router.push("/");
        router.refresh();
      } else {
        setError(data.error || "Login failed");
      }
    } catch {
      setError("Something went wrong. Please try again.");
    }
    setLoading(false);
  };

  return (
    <>
      <HeaderClient />
      <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4">
        <div className="max-w-md w-full">
          <div className="text-center mb-8">
            <Link href="/" className="text-2xl font-bold text-primary">
              <i className="fas fa-shopping-bag mr-2"></i>Ayaan Mart BD
            </Link>
            <h1 className="text-2xl font-bold mt-4 text-gray-800">লগইন</h1>
            <p className="text-gray-500 mt-1">আপনার অ্যাকাউন্টে লগইন করুন</p>
          </div>

          <div className="bg-white rounded-2xl shadow-sm border p-8">
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-600 rounded-lg p-3 mb-4 text-sm">
                <i className="fas fa-exclamation-circle mr-2"></i>{error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="form-label">ইমেইল</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="form-input"
                  placeholder="example@email.com"
                />
              </div>
              <div>
                <label className="form-label">পাসওয়ার্ড</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="form-input"
                  placeholder="********"
                />
              </div>
              <div className="flex items-center justify-between text-sm">
                <label className="flex items-center gap-2 text-gray-600">
                  <input type="checkbox" className="rounded" />
                  মনে রাখুন
                </label>
                <Link href="/forgot-password" className="text-primary hover:underline">পাসওয়ার্ড ভুলে গেছেন?</Link>
              </div>
              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 bg-primary text-white rounded-lg font-semibold hover:bg-primary-hover transition-colors disabled:opacity-50"
              >
                {loading ? <i className="fas fa-spinner fa-spin mr-2"></i> : null}
                লগইন
              </button>
            </form>

            <div className="mt-6 text-center text-sm text-gray-500">
              অ্যাকাউন্ট নেই?{" "}
              <Link href="/register" className="text-primary font-medium hover:underline">
                রেজিস্টার করুন
              </Link>
            </div>

            <div className="mt-4 p-4 bg-gray-50 rounded-lg text-xs text-gray-500">
              <p className="font-medium mb-1">ডেমো অ্যাকাউন্ট:</p>
              <p>Admin: admin@ayaanmartbd.com / admin123</p>
              <p>Customer: demo@ayaanmartbd.com / demo123</p>
            </div>
          </div>
        </div>
      </div>
      <FooterClient />
    </>
  );
}
