"use client";
import { useCartStore } from "@/lib/store";
import Link from "next/link";
import { useState, useEffect } from "react";
import Header from "@/components/HeaderClient";
import Footer from "@/components/FooterClient";

export default function CartPage() {
  const { items, removeItem, updateQuantity, getTotal, clearCart } = useCartStore();
  const [couponCode, setCouponCode] = useState("");
  const [couponDiscount, setCouponDiscount] = useState(0);
  const [couponApplied, setCouponApplied] = useState("");
  const [couponError, setCouponError] = useState("");

  const total = getTotal();
  const deliveryCharge = 0; // Will be set at checkout

  const applyCoupon = async () => {
    if (!couponCode.trim()) return;
    setCouponError("");
    try {
      const res = await fetch("/api/coupons", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: couponCode.trim(), orderTotal: total }),
      });
      const data = await res.json();
      if (data.success) {
        setCouponDiscount(data.discount);
        setCouponApplied(data.code);
        setCouponCode("");
      } else {
        setCouponError(data.error || "Invalid coupon");
      }
    } catch {
      setCouponError("Something went wrong");
    }
  };

  return (
    <>
      <Header />
      <div className="bg-gray-50 min-h-screen">
        <div className="container-custom py-6">
          <div className="flex items-center gap-2 text-sm mb-6">
            <Link href="/" className="text-gray-500 hover:text-primary">Home</Link>
            <i className="fas fa-chevron-right text-xs text-gray-400"></i>
            <span className="text-gray-800 font-medium">কার্ট</span>
          </div>

          {items.length === 0 ? (
            <div className="bg-white rounded-xl border p-12 text-center">
              <div className="text-6xl mb-4">🛒</div>
              <h2 className="text-xl font-bold mb-2">আপনার কার্ট খালি!</h2>
              <p className="text-gray-500 mb-6">কিছু কেনাকাটা করার জন্য নিচের বাটনে ক্লিক করুন</p>
              <Link href="/shop" className="btn-primary">শপিং শুরু করুন</Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <div className="bg-white rounded-xl shadow-sm border overflow-hidden">
                  <div className="p-4 border-b flex justify-between items-center">
                    <h2 className="font-bold text-lg">কার্ট ({items.length} পণ্য)</h2>
                    <button onClick={clearCart} className="text-sm text-red-500 hover:text-red-700">
                      <i className="fas fa-trash mr-1"></i> সব রিমুভ করুন
                    </button>
                  </div>
                  <div className="divide-y">
                    {items.map((item) => (
                      <div key={item.id} className="p-4 flex gap-4 items-center">
                        <img src={item.image} alt={item.name_bn} className="w-20 h-20 rounded-lg object-cover border flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <Link href={`/product/${item.id}`} className="font-medium text-gray-800 hover:text-primary text-sm line-clamp-1">
                            {item.name_bn}
                          </Link>
                          <p className="text-xs text-gray-400">{item.name_en}</p>
                          <p className="font-bold mt-1" style={{ color: "#dc2626" }}>৳{item.price.toLocaleString("en-BD")}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <button onClick={() => updateQuantity(item.id, item.quantity - 1)} className="w-8 h-8 rounded-full border flex items-center justify-center hover:bg-gray-50">
                            <i className="fas fa-minus text-xs"></i>
                          </button>
                          <span className="w-8 text-center font-medium">{item.quantity}</span>
                          <button onClick={() => updateQuantity(item.id, item.quantity + 1)} className="w-8 h-8 rounded-full border flex items-center justify-center hover:bg-gray-50">
                            <i className="fas fa-plus text-xs"></i>
                          </button>
                        </div>
                        <div className="text-right min-w-[80px]">
                          <p className="font-bold">৳{(item.price * item.quantity).toLocaleString("en-BD")}</p>
                        </div>
                        <button onClick={() => removeItem(item.id)} className="text-gray-400 hover:text-red-500 transition-colors">
                          <i className="fas fa-times"></i>
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <div className="bg-white rounded-xl shadow-sm border p-5 sticky top-28">
                  <h3 className="font-bold text-lg mb-4">অর্ডার সামারি</h3>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-500">সাব টোটাল</span>
                      <span className="font-medium">৳{total.toLocaleString("en-BD")}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">ডেলিভারি চার্জ</span>
                      <span className="text-green-600">চেকআউটে নির্ধারিত হবে</span>
                    </div>
                    {couponDiscount > 0 && (
                      <div className="flex justify-between text-green-600">
                        <span>কুপন ডিসকাউন্ট ({couponApplied})</span>
                        <span>-৳{couponDiscount.toLocaleString("en-BD")}</span>
                      </div>
                    )}
                    <div className="border-t pt-3 flex justify-between font-bold text-base">
                      <span>সর্বমোট</span>
                      <span style={{ color: "#dc2626" }}>৳{Math.max(0, total - couponDiscount).toLocaleString("en-BD")}</span>
                    </div>
                  </div>

                  {/* Coupon */}
                  <div className="mt-4 pt-4 border-t">
                    <p className="text-sm font-medium mb-2">কুপন কোড</p>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={couponCode}
                        onChange={(e) => setCouponCode(e.target.value)}
                        placeholder="কুপন কোড লিখুন"
                        className="flex-1 px-3 py-2 border rounded-lg text-sm outline-none"
                      />
                      <button onClick={applyCoupon} className="px-3 py-2 border rounded-lg text-sm font-medium hover:bg-gray-50">
                        Apply
                      </button>
                    </div>
                    {couponError && <p className="text-red-500 text-xs mt-1">{couponError}</p>}
                    {couponApplied && (
                      <p className="text-green-600 text-xs mt-1">
                        <i className="fas fa-check mr-1"></i>কুপন প্রয়োগ হয়েছে: {couponApplied}
                      </p>
                    )}
                  </div>

                  <Link
                    href="/checkout"
                    className="block w-full text-center py-3 rounded-lg text-white font-semibold mt-4 transition-all hover:opacity-90"
                    style={{ backgroundColor: "#dc2626" }}
                  >
                    চেকআউট করুন
                  </Link>
                  <Link href="/shop" className="block text-center text-sm text-gray-500 hover:text-primary mt-3">
                    <i className="fas fa-arrow-left mr-1"></i> আরো কেনাকাটা করুন
                  </Link>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      <Footer />
    </>
  );
}
