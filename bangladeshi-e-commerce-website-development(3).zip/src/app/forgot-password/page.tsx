"use client";
import { useState } from "react";
import Link from "next/link";
import HeaderClient from "@/components/HeaderClient";
import FooterClient from "@/components/FooterClient";

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/auth/reset", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();
      if (data.success) setSent(true);
      else setError(data.error);
    } catch { setError("Something went wrong"); }
    setLoading(false);
  };

  return (
    <>
      <HeaderClient />
      <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4">
        <div className="max-w-md w-full">
          <div className="text-center mb-8">
            <Link href="/" className="text-2xl font-bold text-primary"><i className="fas fa-shopping-bag mr-2"></i>Ayaan Mart BD</Link>
            <h1 className="text-2xl font-bold mt-4">পাসওয়ার্ড রিসেট</h1>
          </div>
          <div className="bg-white rounded-2xl shadow-sm border p-8">
            {sent ? (
              <div className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full mx-auto flex items-center justify-center text-green-500 text-2xl mb-4"><i className="fas fa-check"></i></div>
                <h2 className="font-bold text-lg mb-2">ইমেইল পাঠানো হয়েছে!</h2>
                <p className="text-gray-500 text-sm mb-4">পাসওয়ার্ড রিসেট লিংক আপনার ইমেইলে পাঠানো হয়েছে।</p>
                <Link href="/login" className="text-primary font-medium">লগইন পেজে যান</Link>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                {error && <div className="bg-red-50 border border-red-200 text-red-600 rounded-lg p-3 text-sm"><i className="fas fa-exclamation-circle mr-2"></i>{error}</div>}
                <div>
                  <label className="form-label">ইমেইল</label>
                  <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required className="form-input" placeholder="আপনার ইমেইল লিখুন" />
                </div>
                <button type="submit" disabled={loading} className="w-full py-3 bg-primary text-white rounded-lg font-semibold hover:bg-primary-hover transition-colors disabled:opacity-50">
                  {loading ? <i className="fas fa-spinner fa-spin mr-2"></i> : null}রিসেট লিংক পাঠান
                </button>
                <div className="text-center text-sm">
                  <Link href="/login" className="text-gray-500 hover:text-primary">← লগইন পেজে ফিরুন</Link>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
      <FooterClient />
    </>
  );
}
