import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { getLayoutData } from "@/lib/layout-data";

// Force dynamic rendering: this page reads data from the database and the
// current user's session cookie, so it must never be statically prerendered
// at build time (which would fail if the database isn't reachable during
// the build step, e.g. on a fresh Vercel deployment).
export const dynamic = "force-dynamic";

export default async function AboutPage() {
  const { categories: allCategories, settings: settingsObj, currentUser } = await getLayoutData();

  return (
    <>
      <Header categories={allCategories} settings={settingsObj} currentUser={currentUser} />
      <div className="bg-gray-50 min-h-screen py-12">
        <div className="container-custom max-w-4xl">
          <h1 className="text-3xl font-bold text-gray-800 mb-4">আমাদের সম্পর্কে</h1>
          <div className="bg-white rounded-2xl shadow-sm border p-8 prose prose-sm max-w-none">
            <p>Ayaan Mart BD is Bangladesh's trusted online shopping destination. We provide quality products at the best prices with fast delivery across the country.</p>
            <h2>আমাদের লক্ষ্য</h2>
            <p>বাংলাদেশের প্রতিটি মানুষের কাছে মানসম্পন্ন পণ্য সহজলভ্য করে তোলাই আমাদের মূল লক্ষ্য। আমরা বিশ্বাস করি যে ভালো মানের পণ্য সবার জন্য হওয়া উচিত।</p>
            <h2>কেন আমাদের থেকে কিনবেন?</h2>
            <ul>
              <li>১০০% অরিজিনাল পণ্য</li>
              <li>সর্বনিম্ন মূল্যের গ্যারান্টি</li>
              <li>দ্রুত ডেলিভারি</li>
              <li>নিরাপদ পেমেন্ট সিস্টেম</li>
              <li>সহজ রিটার্ন ও রিফান্ড</li>
              <li>২৪/৭ কাস্টমার সাপোর্ট</li>
            </ul>
            <h2>আমাদের টিম</h2>
            <p>আমাদের টিমে রয়েছে অভিজ্ঞ প্রফেশনালদের একটি দল যারা প্রতিনিয়ত কাজ করে যাচ্ছে আপনার সেরা শপিং এক্সপেরিয়েন্স নিশ্চিত করতে।</p>
          </div>
        </div>
      </div>
      <Footer settings={settingsObj} />
    </>
  );
}
