"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import HeaderClient from "@/components/HeaderClient";
import FooterClient from "@/components/FooterClient";

export default function RegisterPage() {
  const [step, setStep] = useState<"register" | "verify">("register");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [resending, setResending] = useState(false);

  // OTP (single field — verification via mobile number)
  const [otp, setOtp] = useState("");
  const [registeredEmail, setRegisteredEmail] = useState("");
  const [registeredPhone, setRegisteredPhone] = useState("");
  const [successMsg, setSuccessMsg] = useState("");

  const router = useRouter();

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!phone.trim()) {
      setError("মোবাইল ভেরিফিকেশনের জন্য ফোন নাম্বার আবশ্যক");
      return;
    }
    if (password !== confirmPassword) {
      setError("পাসওয়ার্ড মিলছে না");
      return;
    }
    if (password.length < 6) {
      setError("পাসওয়ার্ড কমপক্ষে ৬ অক্ষর হতে হবে");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, password, phone, action: "register" }),
      });
      const data = await res.json();
      if (data.success) {
        setRegisteredEmail(data.email);
        setRegisteredPhone(data.phone);
        setSuccessMsg("আপনার মোবাইল নাম্বারে একটি OTP পাঠানো হয়েছে (একই কোড ইমেইলেও পাঠানো হয়েছে)। দয়া করে ভেরিফাই করুন।");
        setStep("verify");
      } else {
        setError(data.error || "Registration failed");
      }
    } catch {
      setError("Something went wrong. Please try again.");
    }
    setLoading(false);
  };

  const handleVerifyOTP = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!otp.trim()) {
      setError("দয়া করে আপনার মোবাইলে পাঠানো OTP লিখুন");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "verify_otp",
          email: registeredEmail,
          otp,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setSuccessMsg("✅ আপনার মোবাইল নাম্বার ভেরিফাই হয়েছে! অ্যাকাউন্ট এখন Active। রিডাইরেক্ট হচ্ছে...");
        setTimeout(() => {
          router.push("/");
          router.refresh();
        }, 1500);
      } else {
        setError(data.error || "Invalid OTP");
      }
    } catch {
      setError("Something went wrong. Please try again.");
    }
    setLoading(false);
  };

  const handleResendOTP = async () => {
    setError("");
    setResending(true);
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "resend_otp", email: registeredEmail }),
      });
      const data = await res.json();
      if (data.success) {
        setSuccessMsg("নতুন OTP আপনার মোবাইল নাম্বারে পাঠানো হয়েছে।");
      } else {
        setError(data.error || "Failed to resend OTP");
      }
    } catch {
      setError("Something went wrong. Please try again.");
    }
    setResending(false);
  };

  return (
    <>
      <HeaderClient />
      <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4">
        <div className="max-w-md w-full">
          <div className="text-center mb-8">
            <Link href="/" className="text-2xl font-bold text-primary">
              <i className="fas fa-shopping-bag mr-2"></i>Ayaan Mart BD
            </Link>
            <h1 className="text-2xl font-bold mt-4 text-gray-800">
              {step === "register" ? "নতুন অ্যাকাউন্ট তৈরি করুন" : "মোবাইল ভেরিফিকেশন"}
            </h1>
            <p className="text-gray-500 mt-1">
              {step === "register"
                ? "রেজিস্ট্রেশন করে শপিং শুরু করুন"
                : "আপনার মোবাইল নাম্বারে পাঠানো OTP লিখুন"}
            </p>
          </div>

          <div className="bg-white rounded-2xl shadow-sm border p-8">
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-600 rounded-lg p-3 mb-4 text-sm">
                <i className="fas fa-exclamation-circle mr-2"></i>{error}
              </div>
            )}
            {successMsg && (
              <div className="bg-green-50 border border-green-200 text-green-600 rounded-lg p-3 mb-4 text-sm">
                <i className="fas fa-check-circle mr-2"></i>{successMsg}
              </div>
            )}

            {/* STEP 1: Registration Form */}
            {step === "register" && (
              <form onSubmit={handleRegister} className="space-y-4">
                <div>
                  <label className="form-label">নাম *</label>
                  <input type="text" value={name} onChange={(e) => setName(e.target.value)} required className="form-input" placeholder="আপনার পূর্ণ নাম" />
                </div>
                <div>
                  <label className="form-label">ইমেইল *</label>
                  <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required className="form-input" placeholder="example@email.com" />
                </div>
                <div>
                  <label className="form-label">ফোন নাম্বার * <span className="text-xs text-gray-400 font-normal">(OTP এই নাম্বারে পাঠানো হবে)</span></label>
                  <input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} required className="form-input" placeholder="01XXXXXXXXX" />
                </div>
                <div>
                  <label className="form-label">পাসওয়ার্ড *</label>
                  <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required className="form-input" placeholder="কমপক্ষে ৬ অক্ষর" />
                </div>
                <div>
                  <label className="form-label">পাসওয়ার্ড নিশ্চিত করুন *</label>
                  <input type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required className="form-input" placeholder="আবার পাসওয়ার্ড লিখুন" />
                </div>
                <button type="submit" disabled={loading} className="w-full py-3 bg-primary text-white rounded-lg font-semibold hover:bg-primary-hover transition-colors disabled:opacity-50">
                  {loading ? <i className="fas fa-spinner fa-spin mr-2"></i> : null}রেজিস্টার করুন
                </button>
              </form>
            )}

            {/* STEP 2: OTP Verification (Mobile only) */}
            {step === "verify" && (
              <form onSubmit={handleVerifyOTP} className="space-y-4">
                <div className="text-center mb-5">
                  <div className="w-16 h-16 bg-green-100 rounded-full mx-auto flex items-center justify-center text-green-500 text-2xl mb-3">
                    <i className="fas fa-mobile-alt"></i>
                  </div>
                  <p className="text-sm text-gray-500">
                    <strong>{registeredPhone}</strong> নাম্বারে একটি OTP পাঠানো হয়েছে।
                  </p>
                  <p className="text-xs text-gray-400 mt-1">
                    (একই কোড <strong>{registeredEmail}</strong> ইমেইলেও পাঠানো হয়েছে, তবে ভেরিফাই করতে মোবাইলের কোডটি ব্যবহার করুন)
                  </p>
                </div>

                <div>
                  <label className="form-label">মোবাইল OTP *</label>
                  <input
                    type="text"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value)}
                    className="form-input text-center text-2xl tracking-[8px] font-bold"
                    placeholder="______"
                    maxLength={6}
                    autoFocus
                    required
                  />
                </div>

                <button type="submit" disabled={loading} className="w-full py-3 bg-green-600 text-white rounded-lg font-semibold hover:bg-green-700 transition-colors disabled:opacity-50">
                  {loading ? <i className="fas fa-spinner fa-spin mr-2"></i> : <><i className="fas fa-check-circle mr-2"></i>ভেরিফাই করুন</>}
                </button>

                <p className="text-xs text-gray-400 text-center mt-3">
                  OTP ১০ মিনিটের জন্য বৈধ। কোড না পেলে{" "}
                  <button
                    type="button"
                    disabled={resending}
                    className="text-primary underline disabled:opacity-50"
                    onClick={handleResendOTP}
                  >
                    {resending ? "পাঠানো হচ্ছে..." : "পুনরায় পাঠান"}
                  </button>
                </p>
              </form>
            )}

            <div className="mt-6 text-center text-sm text-gray-500">
              ইতিমধ্যেই অ্যাকাউন্ট আছে?{" "}
              <Link href="/login" className="text-primary font-medium hover:underline">
                লগইন করুন
              </Link>
            </div>
          </div>
        </div>
      </div>
      <FooterClient />
    </>
  );
}
