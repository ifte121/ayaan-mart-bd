import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { getLayoutData } from "@/lib/layout-data";

export const dynamic = "force-dynamic";

export default async function PrivacyPage() {
  const { categories: allCategories, settings: settingsObj, currentUser } = await getLayoutData();

  return (
    <>
      <Header categories={allCategories} settings={settingsObj} currentUser={currentUser} />
      <div className="bg-gray-50 min-h-screen py-12">
        <div className="container-custom max-w-4xl">
          <h1 className="text-3xl font-bold text-gray-800 mb-8">প্রাইভেসি পলিসি</h1>
          <div className="bg-white rounded-2xl shadow-sm border p-8 prose prose-sm max-w-none">
            <p>আপনার ব্যক্তিগত তথ্যের সুরক্ষা নিশ্চিত করতে আমরা অঙ্গীকারবদ্ধ।</p>
            <h2>আমরা কি তথ্য সংগ্রহ করি?</h2>
            <ul><li>নাম, ইমেইল, ফোন নাম্বার</li><li>শিপিং ও বিলিং ঠিকানা</li><li>অর্ডার হিস্ট্রি</li></ul>
            <h2>কেন তথ্য সংগ্রহ করি?</h2>
            <ul><li>অর্ডার প্রসেসিং</li><li>ডেলিভারি সেবা</li><li>কাস্টমার সাপোর্ট</li></ul>
            <h2>আমরা কি তথ্য শেয়ার করি?</h2>
            <p>আমরা কখনোই আপনার ব্যক্তিগত তথ্য তৃতীয় পক্ষের সাথে শেয়ার করি না, আইনগত বাধ্যবাধকতা ছাড়া।</p>
          </div>
        </div>
      </div>
      <Footer settings={settingsObj} />
    </>
  );
}
