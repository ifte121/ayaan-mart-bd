import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

const databaseUrl = process.env.DATABASE_URL;

if (!databaseUrl) {
  // IMPORTANT: Do not throw synchronously here.
  // This module (`@/db`) is imported by nearly every page and API route in
  // the app. Throwing at import time can crash the entire build/deploy
  // (e.g. on Vercel) even before a single request is served — including for
  // pages that never touch the database. Instead we log a clear warning and
  // let `pg` fail lazily on the first actual query. That way the site still
  // deploys successfully, and only DB-dependent requests will error until
  // DATABASE_URL is configured correctly (see .env.example, or on Vercel:
  // Project → Settings → Environment Variables).
  console.warn(
    "[Ayaan Mart BD] WARNING: DATABASE_URL is not set. Database queries will fail until it is configured."
  );
}

const globalForDb = globalThis as typeof globalThis & {
  __arenaNextJsPostgresqlPool?: Pool;
};

export const pool =
  globalForDb.__arenaNextJsPostgresqlPool ??
  new Pool({
    connectionString: databaseUrl,
  });

if (process.env.NODE_ENV !== "production") {
  globalForDb.__arenaNextJsPostgresqlPool = pool;
}

export const db = drizzle(pool);
